import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ProjectStatus } from 'src/common/enums/project.status.enum';
import { TaskStatus } from 'src/common/enums/task.status.enum';
import { Project } from 'src/projects/entities/project.entity';
import { Subtask } from 'src/subtasks/entities/subtask.entity';
import { Task } from 'src/tasks/entities/task.entity';
import { Repository } from 'typeorm';
import { StatusStatsDto } from './dto/status-stats.dto';

@Injectable()
export class PerformanceService {
  constructor(
    @InjectRepository(Project)
    private readonly projectRepo: Repository<Project>,
    @InjectRepository(Task)
    private readonly taskRepo: Repository<Task>,
    @InjectRepository(Subtask)
    private readonly subtaskRepo: Repository<Subtask>,
  ) {}

  // async getPerformance(): Promise<PerformanceResponseDto> {
  //   const [projectsTotal, projectsCompleted] = await Promise.all([
  //     this.projectRepo.count(),
  //     this.projectRepo.count({
  //       where: { project_status: ProjectStatus.COMPLETED },
  //     }),
  //   ]);

  //   const [tasksTotal, tasksCompleted] = await Promise.all([
  //     this.taskRepo.count(),
  //     this.taskRepo.count({ where: { status: TaskStatus.COMPLETED } }),
  //   ]);

  //   const [subtasksTotal, subtasksCompleted] = await Promise.all([
  //     this.subtaskRepo.count(),
  //     this.subtaskRepo.count({ where: { status: TaskStatus.COMPLETED } }),
  //   ]);

  //   const calc = (target: number, achieved: number) => ({
  //     target,
  //     achieved,
  //     percentage: target === 0 ? 0 : Math.round((achieved / target) * 100),
  //   });

  //   return {
  //     projects: calc(projectsTotal, projectsCompleted),
  //     tasks: calc(tasksTotal, tasksCompleted),
  //     subtasks: calc(subtasksTotal, subtasksCompleted),
  //   };
  // }

  // src/performance/performance.service.ts
  // ...
  async getPerformance(
    from?: string,
    to?: string,
    granularity: 'month' = 'month',
  ) {
    const fmt = (d: Date) => d.toISOString().slice(0, 10); // YYYY-MM-DD
    const today = new Date();
    const toDate = to ?? fmt(today);
    const start = new Date(today.getFullYear(), today.getMonth() - 5, 1);
    const fromDate = from ?? fmt(start);

    const sql = `
  WITH months AS (
    SELECT (date_trunc('month', $1::date)::date) AS start_month,
           (date_trunc('month', $2::date)::date) AS end_month
  ), series AS (
    SELECT generate_series(
      (SELECT start_month FROM months),
      (SELECT end_month   FROM months),
      interval '1 month'
    )::date AS month_start
  ),
  achieved AS (
    SELECT
      date_trunc('month', p.end_date::timestamp)::date AS month_start,
      COUNT(*)::int AS count
    FROM projects p
    WHERE p.deleted_at IS NULL
      AND p.project_status = $3
      AND p.end_date IS NOT NULL
      AND p.end_date >= $1::date
      AND p.end_date <= $2::date
    GROUP BY 1
  ),
  target AS (
    SELECT
      date_trunc('month', p.end_date::timestamp)::date AS month_start,
      COUNT(*)::int AS count
    FROM projects p
    WHERE p.deleted_at IS NULL
      AND p.end_date IS NOT NULL
      AND p.end_date >= $1::date
      AND p.end_date <= $2::date
    GROUP BY 1
  )
  SELECT
    s.month_start,
    COALESCE(a.count, 0)  AS achieved,
    COALESCE(t.count, 0)  AS target
  FROM series s
  LEFT JOIN achieved a USING (month_start)
  LEFT JOIN target   t USING (month_start)
  ORDER BY s.month_start;
  `;

    const rows: { month_start: string; achieved: number; target: number }[] =
      await this.projectRepo.query(sql, [
        fromDate,
        toDate,
        ProjectStatus.COMPLETED,
      ]);

    const labels: string[] = [];
    const achieved: number[] = [];
    const target: number[] = [];

    for (const r of rows) {
      const d = new Date(r.month_start);
      labels.push(
        d.toLocaleString('en-US', { month: 'short', year: 'numeric' }),
      );
      achieved.push(Number(r.achieved) || 0);
      target.push(Number(r.target) || 0);
    }

    return {
      granularity,
      from: fromDate,
      to: toDate,
      labels,
      series: [
        { key: 'achieved', values: achieved },
        { key: 'target', values: target },
      ],
    };
  }

  async getProjectStatusStats(): Promise<StatusStatsDto[]> {
    const total = await this.projectRepo.count();
    if (total === 0) return [];

    const statuses = [
      ProjectStatus.COMPLETED,
      ProjectStatus.ON_HOLD,
      ProjectStatus.ON_PROGRESS,
      ProjectStatus.PENDING,
      ProjectStatus.OFF_TRACK,
    ];

    const stats: StatusStatsDto[] = [];

    for (const s of statuses) {
      const count = await this.projectRepo.count({
        where: { project_status: s },
      });
      stats.push({
        status: s,
        count,
        percentage: Math.round((count / total) * 100),
      });
    }

    return stats;
  }

  async getTaskStatusStats(): Promise<StatusStatsDto[]> {
    const total = await this.taskRepo.count();
    if (total === 0) return [];

    const statuses = [
      TaskStatus.COMPLETED,
      TaskStatus.ON_HOLD,
      TaskStatus.ON_PROGRESS,
      TaskStatus.PENDING,
    ];

    const stats: StatusStatsDto[] = [];

    for (const s of statuses) {
      const count = await this.taskRepo.count({
        where: { status: s },
      });
      stats.push({
        status: s,
        count,
        percentage: Math.round((count / total) * 100),
      });
    }

    return stats;
  }
}
