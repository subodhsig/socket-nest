import { ApiProperty } from '@nestjs/swagger';

export class PerformanceMetricsDto {
  @ApiProperty()
  target: number;

  @ApiProperty()
  achieved: number;

  @ApiProperty()
  percentage: number;
}

export class PerformanceResponseDto {
  @ApiProperty({ type: PerformanceMetricsDto })
  projects: PerformanceMetricsDto;

  @ApiProperty({ type: PerformanceMetricsDto })
  tasks: PerformanceMetricsDto;

  @ApiProperty({ type: PerformanceMetricsDto })
  subtasks: PerformanceMetricsDto;
}
