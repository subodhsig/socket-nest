import { ApiProperty } from '@nestjs/swagger';

export class StatusStatsDto {
  @ApiProperty()
  status: string;

  @ApiProperty()
  count: number;

  @ApiProperty()
  percentage: number;
}
