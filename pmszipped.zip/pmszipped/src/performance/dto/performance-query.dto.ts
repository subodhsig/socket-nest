import { IsISO8601, IsIn, IsOptional } from 'class-validator';

export class PerformanceQueryDto {
  @IsOptional()
  @IsISO8601()
  from?: string;

  @IsOptional()
  @IsISO8601()
  to?: string;

  @IsIn(['month'])
  // eslint-disable-next-line @typescript-eslint/prefer-as-const
  granularity: 'month' = 'month';
}
