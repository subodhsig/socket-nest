import { Controller, Get, Query } from '@nestjs/common';
import { ApiQuery, ApiTags } from '@nestjs/swagger';
import { PerformanceQueryDto } from './dto/performance-query.dto';
import { StatusStatsDto } from './dto/status-stats.dto';
import { PerformanceService } from './performance.service';

@ApiTags('performance')
@Controller('performance')
export class PerformanceController {
  constructor(private readonly performanceService: PerformanceService) {}

  // @Get()
  // async getCompanyPerformance(): Promise<PerformanceResponseDto> {
  //   return this.performanceService.getPerformance();
  // }
  @Get()
  @ApiQuery({
    name: 'from',
    required: false,
    type: String,
    example: '2025-01-01',
    description: 'Start date (ISO 8601)',
  })
  @ApiQuery({
    name: 'to',
    required: false,
    type: String,
    example: '2025-12-31',
    description: 'End date (ISO 8601)',
  })
  @ApiQuery({
    name: 'granularity',
    required: false,
    enum: ['month'],
    example: 'month',
  })
  async list(@Query() dto: PerformanceQueryDto) {
    // dto.from / dto.to can be undefined now — that's OK
    return this.performanceService.getPerformance(
      dto.from,
      dto.to,
      dto.granularity,
    );
  }

  @Get('projects-stats')
  async getProjectStats(): Promise<StatusStatsDto[]> {
    return this.performanceService.getProjectStatusStats();
  }

  @Get('task-stats')
  async getTaskStats(): Promise<StatusStatsDto[]> {
    return this.performanceService.getTaskStatusStats();
  }
}
