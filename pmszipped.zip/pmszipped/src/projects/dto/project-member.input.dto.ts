// src/projects/dto/project-member.input.dto.ts
import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsUUID } from 'class-validator';
import { ProjectRole } from 'src/common/enums/project.role.enum';

export class ProjectMemberInputDto {
  @ApiProperty({
    description: 'User ID to be added as a member',
    example: '8a6f9a8e-22f6-4f1c-b2f3-1e5d8fb5c0a1',
    format: 'uuid',
  })
  @IsUUID()
  user_id: string;

  @ApiProperty({
    description: 'Role of the user within this project',
    enum: ProjectRole,
    enumName: 'ProjectRole',
    example: ProjectRole.DEVELOPER,
  })
  @IsEnum(ProjectRole)
  role: ProjectRole;
}
