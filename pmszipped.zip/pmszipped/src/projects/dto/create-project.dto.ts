// src/projects/dto/create-project.dto.ts
import {
  ApiExtraModels,
  ApiProperty,
  ApiPropertyOptional,
} from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsEnum,
  IsISO8601,
  IsNotEmpty,
  IsOptional,
  IsString,
  IsUUID,
  MaxLength,
  MinLength,
  ValidateNested,
} from 'class-validator';
import { ProjectRole } from 'src/common/enums/project.role.enum';
import { ProjectStatus } from 'src/common/enums/project.status.enum';
import { ProjectMemberInputDto } from './project-member.input.dto';

@ApiExtraModels(ProjectMemberInputDto)
export class CreateProjectDto {
  @ApiProperty({
    description: 'Human-readable title of the project',
    minLength: 3,
    maxLength: 255,
    example: 'Website Redesign Q4',
  })
  @IsString()
  @IsNotEmpty()
  @MinLength(3)
  @MaxLength(255)
  title: string;

  @ApiPropertyOptional({
    description: 'Optional summary or scope of the project',
    example:
      'Revamp the marketing site with a new design system and accessibility improvements.',
  })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiPropertyOptional({
    description: 'Planned start date (ISO 8601, yyyy-mm-dd)',
    example: '2025-09-15',
    format: 'date',
  })
  @IsISO8601()
  @IsOptional()
  start_date?: string; // e.g., "2025-09-10"

  @ApiPropertyOptional({
    description: 'Planned end date (ISO 8601, yyyy-mm-dd)',
    example: '2025-12-20',
    format: 'date',
  })
  @IsISO8601()
  @IsOptional()
  end_date?: string;

  @ApiPropertyOptional({
    description:
      'Set of roles available/defined for this project (policy-level roles)',
    isArray: true,
    enum: ProjectRole,
    enumName: 'ProjectRole',
    example: [
      ProjectRole.DEVELOPER,
      ProjectRole.MANAGER,
      ProjectRole.TEAM_LEAD,
    ],
  })
  @IsArray()
  @IsEnum(ProjectRole, { each: true })
  @IsOptional()
  project_roles?: ProjectRole[];

  @ApiPropertyOptional({
    description: 'Lifecycle status of the project',
    enum: ProjectStatus,
    enumName: 'ProjectStatus',
    example: ProjectStatus.ON_PROGRESS,
  })
  @IsEnum(ProjectStatus)
  @IsOptional()
  project_status?: ProjectStatus;

  @ApiProperty({
    description: 'User ID of the project owner (must be an existing user)',
    example: 'd3ac2a3d-5b7f-4a3a-8b10-7b2e5ec2a111',
    format: 'uuid',
  })
  @IsUUID()
  ownerUserId: string;

  @ApiPropertyOptional({
    description: 'Optional initial member list to add at creation time',
    type: () => ProjectMemberInputDto,
    isArray: true,
    example: [
      {
        user_id: '8a6f9a8e-22f6-4f1c-b2f3-1e5d8fb5c0a1',
        role: ProjectRole.DEVELOPER,
      },
      {
        user_id: '0f13a330-7a35-4547-8c20-1a3b3a8ca2f9',
        role: ProjectRole.TEAM_LEAD,
      },
    ],
  })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ProjectMemberInputDto)
  @IsOptional()
  members?: ProjectMemberInputDto[];
}
