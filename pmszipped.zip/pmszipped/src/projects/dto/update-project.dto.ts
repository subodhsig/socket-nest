// src/projects/dto/update-project.dto.ts
import { PartialType } from '@nestjs/mapped-types';
import { ApiExtraModels, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsEnum,
  IsISO8601,
  IsOptional,
  IsString,
  IsUUID,
  MaxLength,
  MinLength,
  ValidateNested,
} from 'class-validator';
import { ProjectRole } from 'src/common/enums/project.role.enum';
import { ProjectStatus } from 'src/common/enums/project.status.enum';
import { CreateProjectDto } from './create-project.dto';
import { ProjectMemberInputDto } from './project-member.input.dto';

@ApiExtraModels(ProjectMemberInputDto)
export class UpdateProjectDto extends PartialType(CreateProjectDto) {
  @ApiPropertyOptional({
    description: 'Updated title',
    minLength: 3,
    maxLength: 255,
    example: 'Website Redesign Q4 (Phase 2)',
  })
  @IsString()
  @IsOptional()
  @MinLength(3)
  @MaxLength(255)
  title?: string;

  @ApiPropertyOptional({
    description: 'Updated description',
    example:
      'Include new landing pages, improved performance metrics, and Lighthouse score >= 95.',
  })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiPropertyOptional({
    description: 'Updated start date (ISO 8601, yyyy-mm-dd)',
    example: '2025-10-01',
    format: 'date',
  })
  @IsISO8601()
  @IsOptional()
  start_date?: string;

  @ApiPropertyOptional({
    description: 'Updated end date (ISO 8601, yyyy-mm-dd)',
    example: '2025-12-31',
    format: 'date',
  })
  @IsISO8601()
  @IsOptional()
  end_date?: string;

  @ApiPropertyOptional({
    description: 'Updated policy-level roles for this project',
    isArray: true,
    enum: ProjectRole,
    enumName: 'ProjectRole',
    example: [ProjectRole.DEVELOPER, ProjectRole.MANAGER],
  })
  @IsArray()
  @IsEnum(ProjectRole, { each: true })
  @IsOptional()
  project_roles?: ProjectRole[];

  @ApiPropertyOptional({
    description: 'Updated project status',
    enum: ProjectStatus,
    enumName: 'ProjectStatus',
    example: ProjectStatus.ON_HOLD,
  })
  @IsEnum(ProjectStatus)
  @IsOptional()
  project_status?: ProjectStatus;

  @ApiPropertyOptional({
    description: 'Transfer ownership to another user (admin-only)',
    example: 'f2c58230-51e1-4f7f-8a58-efb6bb33d9f3',
    format: 'uuid',
  })
  @IsUUID()
  @IsOptional()
  ownerUserId?: string;

  @ApiPropertyOptional({
    description:
      'Optional incremental member updates (handled by your service as add/remove/upsert)',
    type: () => ProjectMemberInputDto,
    isArray: true,
    example: [
      {
        user_id: '0f13a330-7a35-4547-8c20-1a3b3a8ca2f9',
        role: ProjectRole.DEVELOPER,
      },
    ],
  })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ProjectMemberInputDto)
  @IsOptional()
  members?: ProjectMemberInputDto[];
}
