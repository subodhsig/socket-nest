// src/projects/projects.controller.ts
import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';

import { GetUser } from 'src/auth/decorators/getuser.decorator';
import { Roles } from 'src/auth/decorators/roles.decorators';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { RolesGuard } from 'src/auth/guards/roles.guard';

import { Role } from 'src/common/enums/user.role.enum';
import { PaginationQueryDto } from 'src/common/pagination/dto/pagination-query.dto';
import { CreateProjectDto } from './dto/create-project.dto';
import { UpdateProjectDto } from './dto/update-project.dto';
import { Project } from './entities/project.entity';
import { ProjectsService } from './projects.service';

type JwtUser = { user_id: string; role: Role };

@ApiTags('Projects')
@ApiBearerAuth()
@Controller('projects')
@UseGuards(JwtAuthGuard, RolesGuard)
export class ProjectsController {
  constructor(private readonly projectsService: ProjectsService) {}

  /** List projects (all authenticated users) */
  @Get('all-projects')
  @ApiOperation({ summary: 'Get all projects' })
  @ApiResponse({
    status: 200,
    description: 'List of projects (paginated)',
    type: Project,
  })
  async findAll(@Query() dto: PaginationQueryDto) {
    return this.projectsService.findAll(dto);
  }

  @ApiOperation({
    summary: 'Get summary of all project and issue for dashboard',
  })
  @Get('summary')
  findAllSummary(@Query() dto: PaginationQueryDto) {
    return this.projectsService.findAllSummary(dto);
  }
  /** Get one project (all authenticated users) */
  @Get(':id')
  @ApiOperation({ summary: 'Get a project by ID' })
  @ApiResponse({ status: 200, description: 'Project found', type: Project })
  @ApiResponse({ status: 404, description: 'Project not found' })
  async findOne(@Param('id') id: string) {
    return this.projectsService.findOne(id);
  }

  /** Create project (ADMIN only) */
  @Post('create-project')
  @Roles(Role.ADMIN)
  @ApiOperation({ summary: 'Create a new project (Admin only)' })
  @ApiResponse({ status: 201, description: 'Project created', type: Project })
  @ApiResponse({ status: 403, description: 'Forbidden' })
  async create(@Body() dto: CreateProjectDto, @GetUser() user: JwtUser) {
    return this.projectsService.create(dto, user);
  }

  /** Update project (ADMIN only) */
  @Patch(':id')
  @Roles(Role.ADMIN)
  @ApiOperation({ summary: 'Update a project (Admin only)' })
  @ApiResponse({ status: 200, description: 'Project updated', type: Project })
  @ApiResponse({ status: 404, description: 'Project not found' })
  @ApiResponse({ status: 403, description: 'Forbidden' })
  async update(
    @Param('id') id: string,
    @Body() dto: UpdateProjectDto,
    @GetUser() user: JwtUser,
  ) {
    return this.projectsService.update(id, dto, user);
  }

  /** Soft delete project (ADMIN only) */
  @Delete(':id')
  @Roles(Role.ADMIN)
  @ApiOperation({ summary: 'Soft delete a project (Admin only)' })
  @ApiResponse({
    status: 200,
    description: 'Project archived successfully',
    schema: { example: { id: 'uuid', status: 'archived' } },
  })
  @ApiResponse({ status: 404, description: 'Project not found' })
  @ApiResponse({ status: 403, description: 'Forbidden' })
  async remove(@Param('id') id: string, @GetUser() user: JwtUser) {
    return this.projectsService.remove(id, user);
  }
}
