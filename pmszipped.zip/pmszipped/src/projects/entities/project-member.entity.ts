import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import { ProjectRole } from '../../common/enums/project.role.enum';
import { User } from '../../user/entities/user.entity';
import { Project } from './project.entity';

@Entity({ name: 'project_members' })
@Unique('UQ_project_member_unique', ['project_id', 'user_id'])
export class ProjectMember {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Index()
  @Column({ type: 'uuid', name: 'project_id' })
  project_id: string;

  @Index()
  @Column({ type: 'uuid', name: 'user_id' })
  user_id: string;

  @ManyToOne(() => Project, (p) => p.members, {
    nullable: false,
    onDelete: 'RESTRICT',
    onUpdate: 'CASCADE',
  })
  @JoinColumn({ name: 'project_id', referencedColumnName: 'project_id' })
  project: Project;

  @ManyToOne(() => User, (u) => u.project_memberships, {
    nullable: false,
    onDelete: 'RESTRICT',
    onUpdate: 'CASCADE',
  })
  @JoinColumn({ name: 'user_id', referencedColumnName: 'user_id' })
  user: User;

  @Column({ type: 'varchar', length: 30 })
  role: ProjectRole;

  @CreateDateColumn({ type: 'timestamptz' })
  joined_at: Date;

  @CreateDateColumn({ type: 'timestamptz' })
  created_at: Date;

  @UpdateDateColumn({ type: 'timestamptz' })
  updated_at: Date;

  // Optional: soft-delete membership changes instead of hard-removing
  @DeleteDateColumn({ type: 'timestamptz', nullable: true })
  deleted_at: Date | null;
}
