import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ name: 'project_targets' })
export class ProjectTarget {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'date' })
  month: Date;

  @Column({ type: 'int' })
  target_count: number;
}
