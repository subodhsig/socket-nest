import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

import { ProjectStatus } from '../../common/enums/project.status.enum';
import { Task } from '../../tasks/entities/task.entity';
import { User } from '../../user/entities/user.entity';
import { ProjectMember } from './project-member.entity';

@Entity({ name: 'projects' })
@Index(['title'])
export class Project {
  @PrimaryGeneratedColumn('uuid')
  project_id: string;

  @Column({ type: 'varchar', length: 255 })
  title: string;

  @Column({ type: 'text', nullable: true })
  description: string | null;

  @Column({ type: 'date', nullable: true })
  start_date: Date | null;

  @Column({ type: 'date', nullable: true })
  end_date: Date | null;

  @Column({ type: 'text', array: true, default: () => "'{}'" })
  project_roles: string[];

  @Column({
    type: 'varchar',
    length: 30,
    default: ProjectStatus.ON_PROGRESS,
  })
  project_status: ProjectStatus;

  @Index()
  @Column({ type: 'uuid', name: 'ownerUserId', nullable: false })
  ownerUserId: string;

  @ManyToOne(() => User, (u) => u.owned_projects, {
    nullable: false,
    onDelete: 'RESTRICT',
    onUpdate: 'CASCADE',
  })
  @JoinColumn({ name: 'ownerUserId', referencedColumnName: 'user_id' })
  owner: User;

  @OneToMany(() => ProjectMember, (pm) => pm.project)
  members: ProjectMember[];

  @OneToMany(() => Task, (t) => t.project)
  tasks: Task[];

  @CreateDateColumn({ type: 'timestamptz' })
  created_at: Date;

  @UpdateDateColumn({ type: 'timestamptz' })
  updated_at: Date;

  // Soft delete flag: NEVER hard delete projects in normal flow
  @DeleteDateColumn({ type: 'timestamptz', nullable: true })
  deleted_at: Date | null;
}
