import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Subtask } from 'src/subtasks/entities/subtask.entity';
import { Task } from 'src/tasks/entities/task.entity';
import { User } from 'src/user/entities/user.entity';
import { Worklog } from 'src/worklogs/entities/worklog.entity';
import { ProjectMember } from './entities/project-member.entity';
import { Project } from './entities/project.entity';
import { ProjectsController } from './projects.controller';
import { ProjectsService } from './projects.service';
import { NotificationModule } from 'src/notification/notification.module';
import { WorklogsModule } from 'src/worklogs/worklogs.module';
import { ProjectTarget } from './entities/project-target.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      User,
      Project,
      ProjectMember,
      Task,
      Subtask,
      Worklog,
      ProjectTarget,
    ]),
    NotificationModule,
    WorklogsModule,
  ],
  controllers: [ProjectsController],
  providers: [ProjectsService],
})
export class ProjectsModule {}
