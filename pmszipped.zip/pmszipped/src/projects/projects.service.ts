import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { NotificationService } from 'src/notification/notification.service';
import { In, IsNull, Repository } from 'typeorm';

import { Role } from 'src/common/enums/user.role.enum';
import { PaginationQueryDto } from 'src/common/pagination/dto/pagination-query.dto';
import { Paginated } from 'src/common/pagination/interface/paginated.interface';
import { PaginationProvider } from 'src/common/pagination/service/pagination.provider';
import { User } from 'src/user/entities/user.entity';
import { CreateProjectDto } from './dto/create-project.dto';
import { ProjectMemberInputDto } from './dto/project-member.input.dto';
import { UpdateProjectDto } from './dto/update-project.dto';
import { ProjectMember } from './entities/project-member.entity';
import { Project } from './entities/project.entity';

/** JWT user shape used throughout services */
type JwtUser = { user_id: string; role: Role };

/** Allow DTOs to optionally carry project_roles in either string or string[] form */
type WithProjectRoles = { project_roles?: string | string[] | null };

//for project and issue in dashboard
type ProjectWithIssues = Project & { issue_count: number };
/**
 * normalizeProjectRoles
 * ---------------------
 * Accepts string | string[] | null/undefined and returns a clean, NON-NULL string[].
 */
function normalizeProjectRoles(
  input: string | string[] | null | undefined,
): string[] {
  if (input == null) return [];
  if (Array.isArray(input))
    return input.map((s) => String(s).trim()).filter(Boolean);
  return String(input)
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
}

/**
 * parseDateOrNull
 * ---------------
 * Converts acceptable DTO date inputs (Date|string|null/undefined) into Date|null.
 */
function parseDateOrNull(d?: string | Date | null): Date | null {
  if (d == null) return null;
  if (d instanceof Date) {
    if (isNaN(d.valueOf())) throw new BadRequestException('Invalid date value');
    return d;
  }
  const asDate = new Date(d);
  if (isNaN(asDate.valueOf()))
    throw new BadRequestException('Invalid date value');
  return asDate;
}

@Injectable()
export class ProjectsService {
  constructor(
    @InjectRepository(Project)
    private readonly projects: Repository<Project>,
    @InjectRepository(ProjectMember)
    private readonly projectMembers: Repository<ProjectMember>,
    @InjectRepository(User)
    private readonly users: Repository<User>,
    private readonly notificationService: NotificationService,
    private readonly pagination: PaginationProvider,
  ) {}

  /**
   * findAll
   * -------
   * Any authenticated user can view all non-archived (soft-not-deleted) projects.
   */
  async findAll(
    dto: PaginationQueryDto,
  ): Promise<Paginated<ProjectWithIssues>> {
    const qb = this.projects
      .createQueryBuilder('p')
      .select('p') // hydrate full Project entity
      .leftJoinAndSelect('p.owner', 'owner')
      .leftJoinAndSelect('p.members', 'members')
      .leftJoinAndSelect('members.user', 'memberUser')
      .where('p.deleted_at IS NULL')
      .addSelect(
        (sq) =>
          sq
            .subQuery()
            .select('COUNT(c.comment_id)') // no alias here
            .from('comments', 'c')
            .innerJoin(
              'subtasks',
              's',
              `s.subtask_id = c.subtask_id
             AND s.deleted_at IS NULL
             AND s.is_available = TRUE`,
            )
            .innerJoin(
              'tasks',
              't',
              `t.task_id = s.task_id
             AND t.deleted_at IS NULL
             AND t.is_available = TRUE`,
            )
            .where(
              `c.deleted_at IS NULL
             AND c.is_available = TRUE
             AND t.project_id = p.project_id`,
            ),
        'issue_count', // alias is here
      );

    const page = await this.pagination.paginateWithRawMerge<
      Project,
      'issue_count'
    >(dto, { qb, mergeKeys: ['issue_count'] as const });

    // normalize to number
    const normalized = page.data.map((proj) => ({
      ...proj,
      issue_count:
        typeof proj.issue_count === 'number'
          ? proj.issue_count
          : Number(proj.issue_count ?? 0),
    }));

    return { ...page, data: normalized };
  }

  /**
   * findOne
   * -------
   * Any authenticated user can view a single non-archived project by id.
   */
  async findOne(id: string) {
    const project = await this.projects.findOne({
      where: { project_id: id, deleted_at: IsNull() },
      relations: ['owner', 'members', 'members.user'],
    });
    if (!project) throw new NotFoundException('Project not found');
    return project;
  }

  /**
   * create (ADMIN only)
   * -------------------
   * - Validates/derives owner (from dto.ownerUserId or current admin)
   * - Validates dates (start <= end) when provided
   * - Normalizes project_roles to string[]
   * - Persists ProjectMembers if provided
   */
  async create(
    dto: CreateProjectDto & Partial<WithProjectRoles>,
    currentUser: JwtUser,
  ) {
    if (currentUser.role !== Role.ADMIN) {
      throw new ForbiddenException('Only ADMIN can create projects');
    }

    // Resolve owner: prefer dto.ownerUserId, else the current admin
    const ownerId = dto.ownerUserId ?? currentUser.user_id;
    const owner = await this.users.findOne({
      where: { user_id: ownerId },
    });
    if (!owner) throw new BadRequestException('Owner user not found');

    const start = parseDateOrNull(dto.start_date);
    const end = parseDateOrNull(dto.end_date);
    if (start && end && start > end) {
      throw new BadRequestException(
        'start_date must be before or equal to end_date',
      );
    }

    const roles = normalizeProjectRoles(dto.project_roles);

    const project = this.projects.create({
      title: dto.title,
      description: dto.description ?? null,
      start_date: start,
      end_date: end,
      project_roles: roles,
      owner,
      project_status: dto.project_status,
    });

    const saved = await this.projects.save(project);

    // 🔹 Add members if provided
    if (dto.members?.length) {
      for (const m of dto.members) {
        await this.addMember(saved.project_id, m);
      }
    }

    //  Notify owner
    await this.notificationService.notifyUser(
      owner,
      `You are assigned as OWNER of project: ${saved.title}`,
    );

    //  Notify all team members
    if (dto.members?.length) {
      const memberIds = dto.members.map((m) => m.user_id);
      const members = await this.users.find({
        where: { user_id: In(memberIds) },
      });

      for (const member of members) {
        const memberRole =
          dto.members.find((m) => m.user_id === member.user_id)?.role ??
          'MEMBER';

        await this.notificationService.notifyUser(
          member,
          `You are assigned as ${memberRole} in project: ${saved.title}`,
        );
      }
    }

    return this.findOne(saved.project_id);
  }

  /**
   * update (ADMIN only)
   * -------------------
   * - Partial update with strict conversions
   * - Validates date ordering if both supplied
   * - Keeps project_roles as non-null string[]
   * - Updates members if provided
   */
  async update(
    id: string,
    dto: UpdateProjectDto & Partial<WithProjectRoles>,
    currentUser: JwtUser,
  ) {
    if (currentUser.role !== Role.ADMIN) {
      throw new ForbiddenException('Only ADMIN can update projects');
    }

    const existing = await this.projects.findOne({
      where: { project_id: id, deleted_at: IsNull() },
      relations: ['owner', 'members', 'members.user'],
    });
    if (!existing) throw new NotFoundException('Project not found');

    const nextStart =
      dto.start_date !== undefined
        ? parseDateOrNull(dto.start_date)
        : existing.start_date;

    const nextEnd =
      dto.end_date !== undefined
        ? parseDateOrNull(dto.end_date)
        : existing.end_date;

    if (nextStart && nextEnd && nextStart > nextEnd) {
      throw new BadRequestException(
        'start_date must be before or equal to end_date',
      );
    }

    const nextRoles =
      dto.project_roles !== undefined
        ? normalizeProjectRoles(dto.project_roles)
        : (existing.project_roles ?? []);

    if (dto.ownerUserId) {
      const newOwner = await this.users.findOne({
        where: { user_id: dto.ownerUserId },
      });
      if (!newOwner) throw new BadRequestException('New owner not found');
      existing.owner = newOwner;
    }

    existing.title = dto.title ?? existing.title;
    existing.description =
      dto.description !== undefined ? dto.description : existing.description;
    existing.start_date = nextStart;
    existing.end_date = nextEnd;
    existing.project_roles = nextRoles;

    if (dto.project_status !== undefined) {
      existing.project_status = dto.project_status;
    }

    const saved = await this.projects.save(existing);

    //Replace members if provided
    if (dto.members) {
      //skiping deleted user safly
      const filteredMembers: ProjectMemberInputDto[] = [];
      for (const m of dto.members) {
        const hasMembership = await this.projectMembers.findOne({
          where: { project_id: saved.project_id, user_id: m.user_id },
        });
        if (hasMembership) {
          filteredMembers.push(m);
          continue;
        }
        const userExists = await this.users.findOne({
          where: { user_id: m.user_id },
        });
        if (userExists) filteredMembers.push(m);
        // else: user hard-deleted → skip silently
      }

      const currentMemberIds = existing.members
        .map((mm) => mm.user?.user_id)
        .filter((id): id is string => !!id);

      const nextMemberIds = dto.members.map((m) => m.user_id);

      // Remove members not in the new list
      for (const userId of currentMemberIds) {
        if (!nextMemberIds.includes(userId)) {
          await this.removeMemberIfExists(saved.project_id, userId);
        }
      }

      // Add or update provided members
      for (const m of dto.members) {
        await this.upsertMember(saved.project_id, m);
      }
    }

    return this.findOne(saved.project_id);
  }

  /**
   * remove (ADMIN only, SOFT DELETE)
   */
  async remove(id: string, currentUser: JwtUser) {
    if (currentUser.role !== Role.ADMIN) {
      throw new ForbiddenException('Only ADMIN can delete projects');
    }

    const existing = await this.projects.findOne({
      where: { project_id: id, deleted_at: IsNull() },
    });
    if (!existing) throw new NotFoundException('Project not found');

    await this.projects.softDelete(id);
    return { id, status: 'archived' as const };
  }

  // -------------------------------
  // 🔹 Helper methods for members
  // -------------------------------

  private async addMember(project_id: string, m: ProjectMemberInputDto) {
    const project = await this.projects.findOne({ where: { project_id } });
    if (!project) throw new NotFoundException('Project not found');

    const user = await this.users.findOne({
      where: { user_id: m.user_id },
    });

    if (!user) throw new NotFoundException('User not found');

    const member = this.projectMembers.create({
      project,
      user,
      role: m.role,
    });

    return this.projectMembers.save(member);
  }

  private async upsertMember(project_id: string, m: ProjectMemberInputDto) {
    const existing = await this.projectMembers.findOne({
      where: { project_id, user_id: m.user_id },
    });

    if (existing) {
      existing.role = m.role;
      return this.projectMembers.save(existing);
    }

    return this.addMember(project_id, m);
  }

  async removeMember(projectId: string, userId: string) {
    const member = await this.projectMembers.findOne({
      where: {
        project: { project_id: projectId },
        user: { user_id: userId },
      },
      relations: ['project', 'user'],
    });

    if (!member) {
      throw new NotFoundException('Member not found in this project');
    }

    await this.projectMembers.remove(member);
    return { message: `User ${userId} removed from project ${projectId}` };
  }

  /**
   * SAFE REMOVE (idempotent)
   * - Use delete() so there is no throw when row doesn't exist
   */
  private async removeMemberIfExists(projectId: string, userId: string) {
    await this.projectMembers.delete({
      project_id: projectId,
      user_id: userId,
    });
    return {
      message: `Member ${userId} removed from project ${projectId} (if existed)`,
    };
  }

  async findAllSummary(
    dto: PaginationQueryDto,
  ): Promise<Paginated<ProjectWithIssues>> {
    const qb = this.projects
      .createQueryBuilder('p')
      .where('p.deleted_at IS NULL')
      .select('p') // keep full entity selection
      .addSelect(
        (sq) =>
          sq
            .subQuery()
            .select('COUNT(c.comment_id)') // no alias here
            .from('comments', 'c')
            .innerJoin(
              'subtasks',
              's',
              `s.subtask_id = c.subtask_id
             AND s.deleted_at IS NULL
             AND s.is_available = TRUE`,
            )
            .innerJoin(
              'tasks',
              't',
              `t.task_id = s.task_id
             AND t.deleted_at IS NULL
             AND t.is_available = TRUE`,
            )
            .where(
              `c.deleted_at IS NULL
             AND c.is_available = TRUE
             AND t.project_id = p.project_id`,
            ),
        'issue_count', // alias is provided here
      );

    const page = await this.pagination.paginateWithRawMerge<
      Project,
      'issue_count'
    >(dto, { qb, mergeKeys: ['issue_count'] as const });

    // normalize to number
    const normalized = page.data.map((p) => ({
      ...p,
      issue_count:
        typeof p.issue_count === 'number'
          ? p.issue_count
          : Number(p.issue_count ?? 0),
    }));

    return { ...page, data: normalized };
  }
}
