import {
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Role } from 'src/common/enums/user.role.enum';
import { IsNull, Repository } from 'typeorm';
import { Subtask } from '../subtasks/entities/subtask.entity';
import { User } from '../user/entities/user.entity';
import { CreateCommentDto } from './dto/create-comment.dto';
import { UpdateCommentDto } from './dto/update-comment.dto';
import { Comment } from './entities/comment.entity';

/**
 * Shape of threaded comment response (nested tree)
 */
export interface ThreadedComment {
  comment_id: string;
  content_html: string;
  created_at: Date;
  author: User | null;
  parent_comment_id: string | null;
  replies: ThreadedComment[];
}

@Injectable()
export class CommentsService {
  constructor(
    @InjectRepository(Comment) private readonly repo: Repository<Comment>,
    @InjectRepository(Subtask) private readonly subtasks: Repository<Subtask>,
    @InjectRepository(User) private readonly users: Repository<User>,
  ) {}

  /**
   * Create a new comment on a subtask
   */
  async create(dto: CreateCommentDto, actor: User): Promise<Comment> {
    const subtask = await this.subtasks.findOne({
      where: { subtask_id: dto.subtask_id },
    });
    if (!subtask) throw new NotFoundException('Subtask not found');

    let parent: Comment | null = null;
    if (dto.parent_comment_id) {
      parent = await this.repo.findOne({
        where: { comment_id: dto.parent_comment_id },
      });
      if (!parent) throw new NotFoundException('Parent comment not found');
    }

    const comment = this.repo.create({
      subtask,
      author: actor,
      content_html: dto.content_html,
      parent_comment: parent ?? null,
    });

    return this.repo.save(comment);
  }

  /**
   * Update a comment (only admin or author)
   */
  async update(
    comment_id: string,
    dto: UpdateCommentDto,
    actor: User,
  ): Promise<Comment> {
    const comment = await this.repo.findOne({
      where: { comment_id },
      relations: ['author'],
    });
    if (!comment) throw new NotFoundException('Comment not found');

    if (
      actor.user_role !== Role.ADMIN &&
      comment.author?.user_id !== actor.user_id
    ) {
      throw new ForbiddenException('Not allowed to edit this comment');
    }

    if (dto.content_html !== undefined) {
      comment.content_html = dto.content_html;
    }

    return this.repo.save(comment);
  }

  /**
   * Delete a comment (only admin or author)
   */
  async remove(comment_id: string, actor: User): Promise<{ success: true }> {
    const comment = await this.repo.findOne({
      where: { comment_id },
      relations: ['author'],
    });
    if (!comment) throw new NotFoundException('Comment not found');

    if (
      actor.user_role !== Role.ADMIN &&
      comment.author?.user_id !== actor.user_id
    ) {
      throw new ForbiddenException('Not allowed to delete this comment');
    }

    comment.is_available = false;
    comment.deleted_at = new Date();
    await this.repo.save(comment);
    return { success: true };
  }

  /**
   * Get all comments for a subtask in threaded (nested) format
   */
  async findBySubtask(subtask_id: string): Promise<ThreadedComment[]> {
    const comments = await this.repo.find({
      where: {
        subtask: { subtask_id },
        deleted_at: IsNull(),
        is_available: true,
      },
      relations: ['author', 'parent_comment'],
      order: { created_at: 'ASC' },
    });

    return this.buildThread(comments);
  }

  /**
   * Build nested comment thread from flat list
   */
  private buildThread(comments: Comment[]): ThreadedComment[] {
    const map = new Map<string, ThreadedComment>();

    // Initialize map with typed objects
    comments.forEach((c) => {
      map.set(c.comment_id, {
        comment_id: c.comment_id,
        content_html: c.content_html,
        created_at: c.created_at,
        author: c.author,
        parent_comment_id: c.parent_comment?.comment_id ?? null,
        replies: [],
      });
    });

    const roots: ThreadedComment[] = [];

    // Assign replies to their parent
    map.forEach((comment) => {
      if (comment.parent_comment_id) {
        const parent = map.get(comment.parent_comment_id);
        if (parent) {
          parent.replies.push(comment);
        }
      } else {
        roots.push(comment);
      }
    });

    return roots;
  }
}
