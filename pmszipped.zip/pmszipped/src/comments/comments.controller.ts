import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiOkResponse,
  ApiOperation,
  ApiParam,
  ApiTags,
} from '@nestjs/swagger';
import { GetUser } from 'src/auth/decorators/getuser.decorator';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { RolesGuard } from 'src/auth/guards/roles.guard';
import { User } from 'src/user/entities/user.entity';
import { CommentsService } from './comments.service';
import { CreateCommentDto } from './dto/create-comment.dto';
import { ThreadedCommentDto } from './dto/threaded-comment.dto';
import { UpdateCommentDto } from './dto/update-comment.dto';

@ApiTags('Comments')
@ApiBearerAuth()
@Controller('comments')
@UseGuards(JwtAuthGuard, RolesGuard)
export class CommentsController {
  constructor(private readonly service: CommentsService) {}

  @Post()
  @ApiOperation({ summary: 'Create a comment on a subtask' })
  @ApiOkResponse({ type: ThreadedCommentDto })
  async create(@Body() dto: CreateCommentDto, @GetUser() actor: User) {
    return this.service.create(dto, actor);
  }

  @Patch(':comment_id')
  @ApiOperation({ summary: 'Update a comment' })
  @ApiParam({ name: 'comment_id', description: 'UUID of the comment' })
  @ApiOkResponse({ type: ThreadedCommentDto })
  async update(
    @Param('comment_id') comment_id: string,
    @Body() dto: UpdateCommentDto,
    @GetUser() actor: User,
  ) {
    return this.service.update(comment_id, dto, actor);
  }

  @Delete(':comment_id')
  @ApiOperation({ summary: 'Delete a comment' })
  @ApiParam({ name: 'comment_id', description: 'UUID of the comment' })
  @ApiOkResponse({ schema: { example: { success: true } } })
  async remove(
    @Param('comment_id') comment_id: string,
    @GetUser() actor: User,
  ) {
    return this.service.remove(comment_id, actor);
  }

  @Get('subtask/:subtask_id')
  @ApiOperation({ summary: 'Get all comments for a subtask (threaded)' })
  @ApiParam({ name: 'subtask_id', description: 'UUID of the subtask' })
  @ApiOkResponse({ type: [ThreadedCommentDto] })
  async findBySubtask(@Param('subtask_id') subtask_id: string) {
    return this.service.findBySubtask(subtask_id);
  }
}
