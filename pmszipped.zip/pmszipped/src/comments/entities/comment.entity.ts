import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Subtask } from '../../subtasks/entities/subtask.entity';
import { User } from '../../user/entities/user.entity';

@Entity({ name: 'comments' })
export class Comment {
  @PrimaryGeneratedColumn('uuid')
  comment_id: string;

  @ManyToOne(() => Subtask, (s) => s.comments, {
    nullable: true, // was false
    onDelete: 'SET NULL', // safer than CASCADE
  })
  @JoinColumn({ name: 'subtask_id' })
  subtask: Subtask | null;

  @ManyToOne(() => User, (u) => u.comments, {
    nullable: true,
    onDelete: 'SET NULL',
  })
  @JoinColumn({ name: 'author_id' })
  author: User | null;

  @Column({ type: 'text' })
  content_html: string;

  @ManyToOne(() => Comment, (c) => c.replies, {
    nullable: true,
    onDelete: 'SET NULL', // was CASCADE
  })
  @JoinColumn({ name: 'parent_comment_id' })
  parent_comment?: Comment | null;

  @OneToMany(() => Comment, (c) => c.parent_comment)
  replies?: Comment[];

  @CreateDateColumn({ type: 'timestamptz' })
  created_at: Date;

  @Column({ type: 'boolean', default: true })
  is_available: boolean;

  @DeleteDateColumn({ type: 'timestamptz', nullable: true })
  deleted_at: Date | null;

  @UpdateDateColumn({ type: 'timestamptz' })
  updated_at: Date;
}
