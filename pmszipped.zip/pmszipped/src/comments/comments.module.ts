import { Module } from '@nestjs/common';
import { MulterModule } from '@nestjs/platform-express';
import { TypeOrmModule } from '@nestjs/typeorm';
import multer from 'multer';
import { Attachment } from 'src/attachments/entities/attachment.entity';
import { AuthModule } from 'src/auth/auth.module';
import { Subtask } from 'src/subtasks/entities/subtask.entity';
import { Task } from 'src/tasks/entities/task.entity';
import { User } from 'src/user/entities/user.entity';
import { CommentsController } from './comments.controller';
import { CommentsService } from './comments.service';
import { Comment } from './entities/comment.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Subtask, Attachment, Comment, User, Task]),
    AuthModule,
    MulterModule.register({
      storage: multer.memoryStorage(),
    }),
  ],
  controllers: [CommentsController],
  providers: [CommentsService],
  exports: [CommentsService],
})
export class CommentsModule {}
