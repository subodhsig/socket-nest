import { ApiProperty } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';

export class UpdateCommentDto {
  @ApiProperty({
    description: 'HTML content of the comment',
    example: '<p>This is a comment</p>',
  })
  @IsString()
  @IsOptional()
  content_html: string;
}
