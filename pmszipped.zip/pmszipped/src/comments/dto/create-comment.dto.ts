import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional, IsString, IsUUID } from 'class-validator';

export class CreateCommentDto {
  @ApiPropertyOptional({
    description: 'Subtask ID for replies',
    example: '014a450b-be6b-414e-92ca-a3432145b7bc',
  })
  @IsUUID()
  subtask_id: string;

  @ApiProperty({
    description: 'HTML content of the comment',
    example: 'This is a comment',
  })
  @IsString()
  @IsNotEmpty()
  content_html: string;

  @ApiPropertyOptional({
    description: 'Parent comment ID for replies',
    example: '014a450b-be6b-414e-92ca-a3432145b7bc',
  })
  @IsOptional()
  @IsUUID()
  parent_comment_id?: string;
}
