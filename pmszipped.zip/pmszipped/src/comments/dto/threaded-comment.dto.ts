import { ApiProperty } from '@nestjs/swagger';
import { User } from 'src/user/entities/user.entity';

export class ThreadedCommentDto {
  @ApiProperty({ description: 'UUID of the comment' })
  comment_id: string;

  @ApiProperty({ description: 'Rich HTML content of the comment' })
  content_html: string;

  @ApiProperty({ description: 'Creation timestamp' })
  created_at: Date;

  @ApiProperty({
    description: 'Author of the comment (can be null if user deleted)',
    type: () => User,
    nullable: true,
  })
  author: User | null;

  @ApiProperty({
    description: 'Parent comment ID if this is a reply',
    nullable: true,
  })
  parent_comment_id: string | null;

  @ApiProperty({
    description: 'Replies (nested threaded comments)',
    type: () => [ThreadedCommentDto],
  })
  replies: ThreadedCommentDto[];
}
