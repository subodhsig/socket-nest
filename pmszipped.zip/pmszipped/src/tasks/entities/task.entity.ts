import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { TaskPriority } from '../../common/enums/task.priority.enum';
import { TaskStatus } from '../../common/enums/task.status.enum';
import { Project } from '../../projects/entities/project.entity';
import { Subtask } from '../../subtasks/entities/subtask.entity';
import { User } from '../../user/entities/user.entity';
import { Worklog } from '../../worklogs/entities/worklog.entity';

@Entity({ name: 'tasks' })
@Index(['title'])
export class Task {
  @PrimaryGeneratedColumn('uuid')
  task_id: string;

  @Column({ length: 255 })
  title: string;

  @Column({ type: 'text', nullable: true })
  description?: string | null;

  // relation to Project (project.project_id)
  @ManyToOne(() => Project, (p) => p.tasks, {
    nullable: true,
    onDelete: 'SET NULL',
  })
  @JoinColumn({ name: 'project_id', referencedColumnName: 'project_id' })
  project?: Project | null;

  // relation to User (assignee) (user.user_id) -> assigned_to_id
  @ManyToOne(() => User, (u) => u.assigned_tasks, {
    nullable: true,
    onDelete: 'SET NULL',
  })
  @JoinColumn({ name: 'assigned_to_id', referencedColumnName: 'user_id' })
  assignee?: User | null;

  @ManyToOne(() => User, (u) => u.owned_tasks, {
    nullable: true,
    onDelete: 'SET NULL',
  })
  @JoinColumn({ name: 'created_by', referencedColumnName: 'user_id' })
  owner?: User | null;

  @Column({ type: 'enum', enum: TaskPriority, default: TaskPriority.MEDIUM })
  priority: TaskPriority;

  @Column({ type: 'enum', enum: TaskStatus, default: TaskStatus.ON_PROGRESS })
  status: TaskStatus;

  @Column({ type: 'timestamptz', nullable: true })
  start_date?: Date | null;

  @Column({ type: 'timestamptz', nullable: true })
  due_date?: Date | null;

  @Column({ type: 'int', nullable: true })
  estimate_minutes?: number | null;

  @Column({ type: 'int', default: 0 })
  order_index: number;

  @OneToMany(() => Subtask, (s) => s.task)
  subtasks?: Subtask[];

  @OneToMany(() => Worklog, (w) => w.task)
  worklogs?: Worklog[];

  @CreateDateColumn({ type: 'timestamptz' })
  created_at: Date;

  @UpdateDateColumn({ type: 'timestamptz' })
  updated_at: Date;

  @DeleteDateColumn({ type: 'timestamptz', nullable: true })
  deleted_at?: Date | null;

  @Column({ type: 'boolean', default: true })
  is_available: boolean;
}
