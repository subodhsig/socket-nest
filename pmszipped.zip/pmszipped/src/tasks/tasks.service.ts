import {
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TaskStatus } from 'src/common/enums/task.status.enum';
import { PaginationQueryDto } from 'src/common/pagination/dto/pagination-query.dto';
import { Paginated } from 'src/common/pagination/interface/paginated.interface';
import { PaginationProvider } from 'src/common/pagination/service/pagination.provider';
import { Project } from 'src/projects/entities/project.entity';
import { User } from 'src/user/entities/user.entity';
import { Worklog } from 'src/worklogs/entities/worklog.entity';
import { IsNull, Repository } from 'typeorm';
import { AssignTaskDto } from './dto/assign-task.dto';
import { ChangeStatusDto } from './dto/change-status.dto';
import { CreateTaskDto } from './dto/create-task.dto';
import { TaskResponseDto } from './dto/task-response.dto';
import { UpdateTaskDto } from './dto/update-task.dto';
import { Task } from './entities/task.entity';

@Injectable()
export class TasksService {
  constructor(
    @InjectRepository(Task) private readonly taskRepo: Repository<Task>,
    @InjectRepository(Project)
    private readonly projectRepo: Repository<Project>,
    @InjectRepository(User) private readonly userRepo: Repository<User>,
    @InjectRepository(Worklog)
    private readonly worklogRepo: Repository<Worklog>,
    private readonly pagination: PaginationProvider,
  ) {}
  // PRIVATE: always return entity for internal use
  private async findOneEntity(
    taskId: string,
    includeDeleted = false,
  ): Promise<Task> {
    const task = await this.taskRepo.findOne({
      where: { task_id: taskId },
      relations: [
        'project',
        'project.members',
        'project.members.user',
        'assignee',
        'subtasks',
        'worklogs',
      ],
      withDeleted: includeDeleted,
    });
    if (!task) throw new NotFoundException('Task not found');
    return task;
  }

  // PUBLIC: controller-facing, returns DTO
  async findOne(
    taskId: string,
    includeDeleted = false,
  ): Promise<TaskResponseDto> {
    const task = await this.findOneEntity(taskId, includeDeleted);

    const assigneeRole = task.project?.members?.find(
      (m) => m.user?.user_id === task.assignee?.user_id,
    )?.role;

    return {
      ...task,
      assignee: task.assignee
        ? { ...task.assignee, role_in_project: assigneeRole ?? null }
        : null,
    };
  }

  async create(dto: CreateTaskDto, creatorId?: string): Promise<Task> {
    const project = await this.projectRepo.findOneBy({
      project_id: dto.projectId,
    });
    if (!project) throw new NotFoundException('Project not found');

    let assignee: User | null = null;
    if (dto.assignedToId) {
      assignee = await this.userRepo.findOne({
        where: { user_id: dto.assignedToId },
      });
      if (!assignee) throw new NotFoundException('Assigned user not found');
    }

    let owner: User | null = null;
    if (creatorId) {
      owner = await this.userRepo.findOne({
        where: { user_id: creatorId },
      });
      if (!owner) throw new NotFoundException('Creator user not found');
    }

    const maxIdxRaw = await this.taskRepo
      .createQueryBuilder('t')
      .select('MAX(t.order_index)', 'max')
      .where('t.project_id = :pid', { pid: project.project_id })
      .getRawOne<{ max?: string }>();

    const maxIdx = parseInt(maxIdxRaw?.max ?? '0', 10) || 0;
    const nextIndex = maxIdx + 1;
    const task = this.taskRepo.create({
      title: dto.title,
      description: dto.description ?? null,
      project,
      assignee: assignee ?? null,
      owner: owner ?? null,
      priority: dto.priority ?? undefined,
      status: dto.status ?? undefined,
      start_date: dto.start_date ? new Date(dto.start_date) : null,
      due_date: dto.due_date ? new Date(dto.due_date) : null,
      estimate_minutes: dto.estimate_minutes ?? null,
      order_index: nextIndex,
    });

    const saved = await this.taskRepo.save(task);
    return saved;
  }

  // async findAllByProject(projectId: string): Promise<Task[]> {
  //   return this.taskRepo
  //     .createQueryBuilder('t')
  //     .leftJoinAndSelect('t.assignee', 'assignee')
  //     .leftJoinAndSelect('t.subtasks', 'subtasks')
  //     .where('t.project_id = :pid', { pid: projectId })
  //     .andWhere('t.deleted_at IS NULL')
  //     .orderBy('t.order_index', 'ASC')
  //     .addOrderBy('t.created_at', 'DESC')
  //     .getMany();
  // }

  // async findAllByUser(userId: string): Promise<Task[]> {
  //   return this.taskRepo
  //     .createQueryBuilder('t')
  //     .leftJoinAndSelect('t.project', 'project')
  //     .leftJoinAndSelect('t.subtasks', 'subtasks')
  //     .where('t.assigned_to_id = :uid', { uid: userId })
  //     .andWhere('t.deleted_at IS NULL')
  //     .orderBy('t.due_date', 'ASC')
  //     .addOrderBy('t.priority', 'DESC')
  //     .getMany();
  // }

  async findAllByProject(
    projectId: string,
    dto: PaginationQueryDto,
  ): Promise<Paginated<Task>> {
    const qb = this.taskRepo
      .createQueryBuilder('t')
      .leftJoinAndSelect('t.assignee', 'assignee')
      .leftJoinAndSelect('t.owner', 'owner')
      .leftJoinAndSelect(
        't.subtasks',
        'subtasks',
        'subtasks.deleted_at IS NULL AND subtasks.is_available = true',
      )
      .where('t.project_id = :pid', { pid: projectId })
      .andWhere('t.deleted_at IS NULL');

    return this.pagination.paginate(dto, { qb });
  }

  async findAllByUser(
    userId: string,
    dto: PaginationQueryDto,
  ): Promise<Paginated<Task>> {
    const qb = this.taskRepo
      .createQueryBuilder('t')
      .leftJoinAndSelect('t.project', 'project')
      .leftJoinAndSelect('t.owner', 'owner')
      .leftJoinAndSelect(
        't.subtasks',
        'subtasks',
        'subtasks.deleted_at IS NULL AND subtasks.is_available = true',
      )
      .where('t.assigned_to_id = :uid', { uid: userId })
      .andWhere('t.deleted_at IS NULL');

    return this.pagination.paginate(dto, { qb });
  }

  async update(
    taskId: string,
    dto: UpdateTaskDto & { order_index?: number },
  ): Promise<Task> {
    const task = await this.findOneEntity(taskId);

    if (dto.projectId !== undefined && dto.projectId !== null) {
      const project = await this.projectRepo.findOneBy({
        project_id: dto.projectId,
      });
      if (!project) throw new NotFoundException('Project not found');
      task.project = project;
    }

    if (dto.assignedToId !== undefined) {
      if (dto.assignedToId === null) {
        task.assignee = null;
      } else {
        const user = await this.userRepo.findOne({
          where: { user_id: dto.assignedToId },
        });
        if (!user) throw new NotFoundException('Assigned user not found');
        task.assignee = user;
      }
    }

    if (dto.title !== undefined) task.title = dto.title;
    if (dto.description !== undefined) task.description = dto.description;
    if (dto.priority !== undefined) task.priority = dto.priority;
    if (dto.status !== undefined) task.status = dto.status;
    if (dto.start_date !== undefined)
      task.start_date = dto.start_date ? new Date(dto.start_date) : null;
    if (dto.due_date !== undefined)
      task.due_date = dto.due_date ? new Date(dto.due_date) : null;
    if (dto.estimate_minutes !== undefined)
      task.estimate_minutes = dto.estimate_minutes;
    if (dto.order_index !== undefined) task.order_index = dto.order_index;

    return this.taskRepo.save(task);
  }

  async remove(taskId: string) {
    const exists = await this.taskRepo.findOneBy({ task_id: taskId });
    if (!exists) throw new NotFoundException('Task not found');
    await this.taskRepo.softDelete({ task_id: taskId });
    return { id: taskId, status: 'archived' as const };
  }

  async restore(taskId: string): Promise<void> {
    const deleted = await this.taskRepo.findOne({
      where: { task_id: taskId },
      withDeleted: true,
    });
    if (!deleted || !deleted.deleted_at)
      throw new NotFoundException('Deleted task not found');
    await this.taskRepo.restore({ task_id: taskId });
  }

  async hardRemove(taskId: string): Promise<void> {
    const task = await this.taskRepo.findOne({
      where: { task_id: taskId },
      withDeleted: true,
    });
    if (!task) throw new NotFoundException('Task not found');
    await this.taskRepo.remove(task);
  }

  async assign(taskId: string, dto: AssignTaskDto): Promise<Task> {
    const task = await this.findOneEntity(taskId);
    const user = await this.userRepo.findOne({
      where: { user_id: dto.assignedToId },
    });
    if (!user) throw new NotFoundException('User not found');
    task.assignee = user;
    return this.taskRepo.save(task);
  }

  async changeStatus(
    taskId: string,
    dto: ChangeStatusDto,
    actorUserId?: string,
    actorRoles?: string[],
  ): Promise<Task> {
    const task = await this.findOneEntity(taskId);
    const isAssigned = task.assignee?.user_id === actorUserId;
    const isAdminLike =
      actorRoles?.includes('ADMIN') || actorRoles?.includes('MANAGER');

    if (!isAssigned && !isAdminLike)
      throw new ForbiddenException(
        'Not allowed to change status for this task',
      );

    task.status = dto.status;
    return this.taskRepo.save(task);
  }

  async getTimeSpentForTask(taskId: string): Promise<number> {
    const raw = await this.worklogRepo
      .createQueryBuilder('w')
      .innerJoin('w.task', 't')
      .where('t.task_id = :taskId', { taskId })
      .andWhere('w.deleted_at IS NULL') // <- remove this line if no soft delete
      .select('COALESCE(SUM(w.minutes), 0)', 'sum')
      .getRawOne<{ sum: string }>();

    return Number(raw?.sum ?? 0);
  }

  // async getProjectBoardStats(projectId: string) {
  //   const timeRaw = await this.worklogRepo
  //     .createQueryBuilder('w')
  //     .select('SUM(w.duration_minutes)', 'totalMinutes')
  //     .innerJoin('w.task', 't')
  //     .where('t.project_id = :pid', { pid: projectId })
  //     .andWhere('t.deleted_at IS NULL')
  //     .andWhere('w.deleted_at IS NULL')
  //     .getRawOne<{ totalMinutes?: string }>();

  //   const totalMinutes = Number(timeRaw?.totalMinutes ?? 0);

  //   const statusesRaw = await this.taskRepo
  //     .createQueryBuilder('t')
  //     .select('t.status', 'status')
  //     .addSelect('COUNT(*)', 'count')
  //     .where('t.project_id = :pid', { pid: projectId })
  //     .andWhere('t.deleted_at IS NULL')
  //     .groupBy('t.status')
  //     .getRawMany<{ status: string; count: string }>();

  //   const statuses: Record<string, number> = {};
  //   statusesRaw.forEach((r) => (statuses[r.status] = Number(r.count)));

  //   const now = new Date();
  //   const next7 = new Date(now);
  //   next7.setDate(now.getDate() + 7);

  //   const upcomingWhere = {
  //     project: { project_id: projectId },
  //     due_date: Between(now, next7),
  //     deleted_at: IsNull(),
  //   };

  //   const overdueWhere = {
  //     project: { project_id: projectId },
  //     due_date: Between(new Date(0), now),
  //     status: Not(TaskStatus.COMPLETED),
  //     deleted_at: IsNull(),
  //   };

  //   const upcoming = await this.taskRepo.count({ where: upcomingWhere });
  //   const overdue = await this.taskRepo.count({ where: overdueWhere });

  //   return {
  //     timeSpentMinutes: totalMinutes,
  //     statusCounts: statuses,
  //     upcomingDeadlinesCount: upcoming,
  //     overdueCount: overdue,
  //   };
  // }

  async findDeletedByProject(projectId: string): Promise<Task[]> {
    return this.taskRepo
      .createQueryBuilder('t')
      .withDeleted()
      .leftJoinAndSelect('t.assignee', 'assignee')
      .where('t.project_id = :pid', { pid: projectId })
      .andWhere('t.deleted_at IS NOT NULL')
      .getMany();
  }

  async findAllTasks(): Promise<Task[]> {
    return this.taskRepo.find({ where: { deleted_at: IsNull() } });
  }
  // async sumAllTaskEstimate() {
  //   const raw = await this.taskRepo
  //     .createQueryBuilder('t')
  //     .select('SUM(t.estimate_minutes)', 'totalEstimate')
  //     .where('t.deleted_at IS NULL')
  //     .getRawOne();
  //   return Number((raw as { totalEstimate?: string })?.totalEstimate ?? 0);
  // }
  // async TotalTimeOfCompletedTasks(): Promise<number> {
  //   const raw = await this.taskRepo
  //     .createQueryBuilder('t')
  //     .select('SUM(t.estimate_minutes)', 'totalEstimate')
  //     .where('t.status = :status', { status: TaskStatus.COMPLETED })
  //     .andWhere('t.deleted_at IS NULL')
  //     .getRawOne();
  //   return Number((raw as { totalEstimate?: string })?.totalEstimate ?? 0);
  // }

  // task completed time, all tasks estimate time, completed percentage for graph in worklog

  async CompletedTimeOfTaskAndEstimateTotalTime() {
    const [completedRaw, allRaw] = await Promise.all([
      this.taskRepo
        .createQueryBuilder('t')
        .select('SUM(t.estimate_minutes)', 'totalEstimate')
        .where('t.status = :status', { status: TaskStatus.COMPLETED })
        .andWhere('t.deleted_at IS NULL')
        .getRawOne(),

      this.taskRepo
        .createQueryBuilder('t')
        .select('SUM(t.estimate_minutes)', 'totalEstimate')
        .where('t.deleted_at IS NULL')
        .getRawOne(),
    ]);

    const completedTasksTime = Number(
      (completedRaw as { totalEstimate?: string })?.totalEstimate ?? 0,
    );
    const allTasksEstimate = Number(
      (allRaw as { totalEstimate?: string })?.totalEstimate ?? 0,
    );

    const completedPercentage =
      allTasksEstimate > 0 ? (completedTasksTime / allTasksEstimate) * 100 : 0;

    return {
      completedTasksTime,
      allTasksEstimate,
      completedPercentage: Number(completedPercentage.toFixed(2)), // rounded to 2 decimals
    };
  }
}
