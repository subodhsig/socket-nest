import { ApiProperty } from '@nestjs/swagger';
import { IsUUID } from 'class-validator';

export class AssignTaskDto {
  @ApiProperty({
    description: 'UUID of Assignee ID',
    example: '6ab80583-117b-4dd6-97cc-46dc2a95ef97',
    format: 'uuid',
  })
  @IsUUID()
  assignedToId: string;
}
