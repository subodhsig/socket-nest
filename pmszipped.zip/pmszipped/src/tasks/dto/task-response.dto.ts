import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { ProjectRole } from 'src/common/enums/project.role.enum';
import { TaskPriority } from 'src/common/enums/task.priority.enum';
import { TaskStatus } from 'src/common/enums/task.status.enum';
import { Project } from 'src/projects/entities/project.entity';
import { Subtask } from 'src/subtasks/entities/subtask.entity';
import { Worklog } from 'src/worklogs/entities/worklog.entity';

export class AssigneeWithRoleDto {
  @ApiProperty({ example: '67dc727e-6681-44f4-b198-09f7d31c5f58' })
  user_id: string;

  @ApiProperty({ example: 'John' })
  first_name: string;

  @ApiProperty({ example: 'Doe' })
  last_name: string;

  @ApiProperty({ example: 'john@example.com' })
  email: string;

  @ApiPropertyOptional({
    enum: ProjectRole,
    example: ProjectRole.STAKEHOLDER,
    description: 'Role of the assignee in the project',
    nullable: true,
  })
  role_in_project?: ProjectRole | null;
}

export class TaskResponseDto {
  @ApiProperty()
  task_id: string;

  @ApiProperty()
  title: string;

  @ApiPropertyOptional({ nullable: true })
  description?: string | null;

  @ApiPropertyOptional({ type: () => Project, nullable: true })
  project?: Project | null;

  @ApiPropertyOptional({ type: () => AssigneeWithRoleDto, nullable: true })
  assignee?: AssigneeWithRoleDto | null;

  @ApiPropertyOptional({ type: Object, nullable: true })
  owner?: any;

  @ApiProperty({ enum: TaskPriority })
  priority: TaskPriority;

  @ApiProperty({ enum: TaskStatus })
  status: TaskStatus;

  @ApiPropertyOptional({ type: () => Date, nullable: true })
  start_date?: Date | null;

  @ApiPropertyOptional({ type: () => Date, nullable: true })
  due_date?: Date | null;

  @ApiPropertyOptional({ example: 120, nullable: true })
  estimate_minutes?: number | null;

  @ApiProperty()
  order_index: number;

  @ApiPropertyOptional({ type: [Subtask], nullable: true })
  subtasks?: Subtask[] | null;

  @ApiPropertyOptional({ type: [Worklog], nullable: true })
  worklogs?: Worklog[] | null;

  @ApiProperty()
  created_at: Date;

  @ApiProperty()
  updated_at: Date;

  @ApiPropertyOptional({ nullable: true })
  deleted_at?: Date | null;
}
