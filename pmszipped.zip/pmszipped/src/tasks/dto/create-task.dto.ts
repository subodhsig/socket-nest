// src/tasks/dto/create-task.dto.ts
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsDateString,
  IsEnum,
  IsInt,
  IsOptional,
  IsString,
  IsUUID,
  Min,
} from 'class-validator';
import { TaskPriority } from 'src/common/enums/task.priority.enum';
import { TaskStatus } from 'src/common/enums/task.status.enum';

export class CreateTaskDto {
  @ApiProperty({
    description: 'Short title of the task',
    example: 'Design landing page hero',
    maxLength: 255,
  })
  @IsString()
  title: string;

  @ApiPropertyOptional({
    description: 'Detailed description (optional)',
    example: 'Create hero design matching brand guidelines and add CTA',
    type: 'string',
  })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({
    description: 'Project UUID to which this task belongs',
    example: 'd290f1ee-6c54-4b01-90e6-d701748f0851',
    format: 'uuid',
  })
  @IsUUID()
  projectId: string;

  @ApiPropertyOptional({
    description: 'User UUID to assign this task to (optional)',
    example: 'a3e1f6b2-8f3a-4c3a-b9a2-ff6a6a5f7b1c',
    format: 'uuid',
  })
  @IsOptional()
  @IsUUID()
  assignedToId?: string;

  @ApiPropertyOptional({
    description: 'Priority of the task',
    enum: TaskPriority,
    example: TaskPriority.MEDIUM,
  })
  @IsOptional()
  @IsEnum(TaskPriority)
  priority?: TaskPriority;

  @ApiPropertyOptional({
    description: 'Initial status of the task',
    enum: TaskStatus,
    example: TaskStatus.ON_PROGRESS,
  })
  @IsOptional()
  @IsEnum(TaskStatus)
  status?: TaskStatus;

  @ApiPropertyOptional({
    description: 'Planned start date/time (ISO 8601)',
    example: '2025-09-15T09:00:00Z',
    format: 'date-time',
    type: 'string',
  })
  @IsOptional()
  @IsDateString()
  start_date?: string;

  @ApiPropertyOptional({
    description: 'Planned due date/time (ISO 8601)',
    example: '2025-09-22T17:00:00Z',
    format: 'date-time',
    type: 'string',
  })
  @IsOptional()
  @IsDateString()
  due_date?: string;

  @ApiPropertyOptional({
    description: 'Estimated time in minutes (optional, integer >= 0)',
    example: 120,
    minimum: 0,
    type: 'integer',
  })
  @IsOptional()
  @IsInt()
  @Min(0)
  estimate_minutes?: number;
}
