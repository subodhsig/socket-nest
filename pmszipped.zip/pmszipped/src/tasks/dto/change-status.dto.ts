import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty } from 'class-validator';
import { TaskStatus } from 'src/common/enums/task.status.enum';

export class ChangeStatusDto {
  @ApiProperty({
    description: 'Status of the task',
    enum: TaskStatus,
    example: TaskStatus.ON_PROGRESS,
  })
  @IsNotEmpty()
  @IsEnum(TaskStatus)
  status: TaskStatus;
}
