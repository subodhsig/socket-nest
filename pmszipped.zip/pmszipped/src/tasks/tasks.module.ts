import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Task } from './entities/task.entity';
import { TasksController } from './tasks.controller';
import { TasksService } from './tasks.service';

import { AuthModule } from 'src/auth/auth.module';
import { Project } from 'src/projects/entities/project.entity';
import { Subtask } from 'src/subtasks/entities/subtask.entity';
import { User } from 'src/user/entities/user.entity';
import { Worklog } from 'src/worklogs/entities/worklog.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Task, Worklog, Subtask, Project, User]),
    AuthModule,
  ],
  controllers: [TasksController],
  providers: [TasksService],
  exports: [TasksService],
})
export class TasksModule {}
