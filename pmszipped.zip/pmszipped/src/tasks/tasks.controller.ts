import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  ParseUUIDPipe,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';
import { GetUser } from 'src/auth/decorators/getuser.decorator';
import { Roles } from 'src/auth/decorators/roles.decorators';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { RolesGuard } from 'src/auth/guards/roles.guard';
import { Role } from 'src/common/enums/user.role.enum';
import { PaginationQueryDto } from 'src/common/pagination/dto/pagination-query.dto';
import { AssignTaskDto } from './dto/assign-task.dto';
import { ChangeStatusDto } from './dto/change-status.dto';
import { CreateTaskDto } from './dto/create-task.dto';
import { TaskResponseDto } from './dto/task-response.dto';
import { UpdateTaskDto } from './dto/update-task.dto';
import { Task } from './entities/task.entity';
import { TasksService } from './tasks.service';

type JwtUser = {
  user_id: string;
  role: Role;
};

@ApiTags('tasks')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('tasks')
export class TasksController {
  constructor(private readonly tasksService: TasksService) {}

  @Get('all-tasks')
  @ApiOperation({ summary: 'Get all tasks' })
  async findAllTasks(): Promise<Task[]> {
    return this.tasksService.findAllTasks();
  }
  // Create task (ADMIN only)
  @Post()
  @ApiOperation({ summary: 'Create Task by Admin' })
  @UseGuards(RolesGuard)
  @Roles(Role.ADMIN)
  async create(@Body() dto: CreateTaskDto, @GetUser() user: JwtUser) {
    return this.tasksService.create(dto, user.user_id);
  }

  // List tasks by project
  @Get('project/:projectId')
  @ApiOperation({ summary: 'Get task by project id' })
  findByProject(
    @Param('projectId', new ParseUUIDPipe()) projectId: string,
    @Query() dto: PaginationQueryDto,
  ) {
    return this.tasksService.findAllByProject(projectId, dto);
  }

  // Project board stats
  //todo: enable when board feature is added
  // @Get('project/:projectId/stats')
  // projectStats(@Param('projectId', new ParseUUIDPipe()) projectId: string) {
  //   return this.tasksService.getProjectBoardStats(projectId);
  // }

  // Deleted tasks for a project (ADMIN)
  @UseGuards(RolesGuard)
  @ApiOperation({ summary: 'Get Deleted tasks for a project (ADMIN)' })
  @Roles(Role.ADMIN)
  @Get('project/:projectId/trash')
  findDeletedByProject(
    @Param('projectId', new ParseUUIDPipe()) projectId: string,
  ) {
    return this.tasksService.findDeletedByProject(projectId);
  }

  // Tasks assigned to current user
  @Get('my')
  @ApiOperation({ summary: 'Get my tasks' })
  findMyTasks(@GetUser() user: JwtUser, @Query() dto: PaginationQueryDto) {
    return this.tasksService.findAllByUser(user.user_id, dto);
  }

  // Task time spent
  @Get(':taskId/time-spent')
  @ApiOperation({ summary: 'Get time spent in task' })
  timeSpent(@Param('taskId', new ParseUUIDPipe()) taskId: string) {
    return this.tasksService.getTimeSpentForTask(taskId);
  }

  // Get single task
  // @Get(':taskId')
  // findOne(@Param('taskId', new ParseUUIDPipe()) taskId: string) {
  //   return this.tasksService.findOne(taskId);
  // }

  @Get(':taskId')
  @ApiOperation({ summary: 'Get task by task id' })
  @ApiOkResponse({
    type: TaskResponseDto,
    description: 'Task with project, assignee (with role), subtasks',
  })
  async findOne(
    @Param('taskId', new ParseUUIDPipe()) taskId: string,
  ): Promise<TaskResponseDto> {
    return this.tasksService.findOne(taskId);
  }

  // Update task (ADMIN)
  @UseGuards(RolesGuard)
  @ApiOperation({ summary: 'Update task by Admin' })
  @Roles(Role.ADMIN)
  @Patch(':taskId')
  update(
    @Param('taskId', new ParseUUIDPipe()) taskId: string,
    @Body() dto: UpdateTaskDto,
  ) {
    return this.tasksService.update(taskId, dto);
  }

  // Assign task (ADMIN)
  @UseGuards(RolesGuard)
  @ApiOperation({ summary: 'Assign task (ADMIN)' })
  @Roles(Role.ADMIN)
  @Patch(':taskId/assign')
  assign(
    @Param('taskId', new ParseUUIDPipe()) taskId: string,
    @Body() dto: AssignTaskDto,
  ) {
    return this.tasksService.assign(taskId, dto);
  }

  // Change status (allowed for assigned user or admin)
  @ApiOperation({
    summary: 'Change status (allowed for assigned user or admin)',
  })
  @Patch(':taskId/status')
  changeStatus(
    @Param('taskId', new ParseUUIDPipe()) taskId: string,
    @Body() dto: ChangeStatusDto,
    @GetUser() user: JwtUser,
  ) {
    // wrap single role in array for service
    return this.tasksService.changeStatus(taskId, dto, user.user_id, [
      user.role,
    ]);
  }

  // Soft delete (ADMIN)
  @UseGuards(RolesGuard)
  @ApiOperation({
    summary: 'Soft delete Admin',
  })
  @Roles(Role.ADMIN)
  @Delete(':taskId')
  softDelete(@Param('taskId', new ParseUUIDPipe()) taskId: string) {
    return this.tasksService.remove(taskId);
  }

  // Restore (ADMIN)
  @UseGuards(RolesGuard)
  @ApiOperation({
    summary: 'Restore (ADMIN)',
  })
  @Roles(Role.ADMIN)
  @Patch(':taskId/restore')
  restore(@Param('taskId', new ParseUUIDPipe()) taskId: string) {
    return this.tasksService.restore(taskId);
  }

  // Hard delete (ADMIN)
  @UseGuards(RolesGuard)
  @ApiOperation({
    summary: 'Hard delete (ADMIN)',
  })
  @Roles(Role.ADMIN)
  @Delete(':taskId/hard')
  hardDelete(@Param('taskId', new ParseUUIDPipe()) taskId: string) {
    return this.tasksService.hardRemove(taskId);
  }
  // @Get('remaining/total-estimate')
  // async sumTaskEstimate() {
  //   return this.tasksService.sumAllTaskEstimate();
  // }

  // @Get('allTask/total-spent')
  // async sumTaskSpent() {
  //   return this.tasksService.TotalTimeOfCompletedTasks();
  // }

  // all task status count such as task completed and total estimate time
  @ApiOperation({
    summary:
      'all task status count such as task completed and total estimate time',
  })
  @Get('all/status-count')
  async getStatusCount() {
    return this.tasksService.CompletedTimeOfTaskAndEstimateTotalTime();
  }
}
