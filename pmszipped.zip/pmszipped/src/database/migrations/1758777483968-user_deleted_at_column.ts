import { MigrationInterface, QueryRunner } from "typeorm";

export class UserDeletedAtColumn1758777483968 implements MigrationInterface {
    name = 'UserDeletedAtColumn1758777483968'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "user" ALTER COLUMN "deleteAt" DROP DEFAULT`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "user" ALTER COLUMN "deleteAt" SET DEFAULT now()`);
    }

}
