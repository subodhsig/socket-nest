import { MigrationInterface, QueryRunner } from "typeorm";

export class DeletedAtcolumnadded1758772933425 implements MigrationInterface {
    name = 'DeletedAtcolumnadded1758772933425'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "user" ADD "deleteAt" TIMESTAMP WITH TIME ZONE DEFAULT now()`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "user" DROP COLUMN "deleteAt"`);
    }

}
