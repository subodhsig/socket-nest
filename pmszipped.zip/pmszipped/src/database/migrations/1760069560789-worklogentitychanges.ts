import { MigrationInterface, QueryRunner } from "typeorm";

export class Worklogentitychanges1760069560789 implements MigrationInterface {
    name = 'Worklogentitychanges1760069560789'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "worklogs" ADD "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "worklogs" ADD "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "worklogs" ADD "deleted_at" TIMESTAMP WITH TIME ZONE`);
        await queryRunner.query(`CREATE INDEX "IDX_3ddbc0818ceb9308c8e9d47876" ON "worklogs" ("user_id") `);
        await queryRunner.query(`CREATE INDEX "IDX_9f4bdfd65c712bb44bda6f4170" ON "worklogs" ("task_id") `);
        await queryRunner.query(`CREATE INDEX "IDX_e46b0586550fec335550200782" ON "worklogs" ("date") `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`DROP INDEX "public"."IDX_e46b0586550fec335550200782"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_9f4bdfd65c712bb44bda6f4170"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_3ddbc0818ceb9308c8e9d47876"`);
        await queryRunner.query(`ALTER TABLE "worklogs" DROP COLUMN "deleted_at"`);
        await queryRunner.query(`ALTER TABLE "worklogs" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "worklogs" DROP COLUMN "created_at"`);
    }

}
