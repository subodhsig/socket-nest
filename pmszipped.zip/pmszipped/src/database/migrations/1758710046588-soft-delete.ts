import { MigrationInterface, QueryRunner } from "typeorm";

export class SoftDelete1758710046588 implements MigrationInterface {
    name = 'SoftDelete1758710046588'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "attachments" DROP CONSTRAINT "FK_8c06b12c64701f1c4f5235288b0"`);
        await queryRunner.query(`ALTER TABLE "comments" DROP CONSTRAINT "FK_6e8005efa61bc3ec37a0b0cc1ae"`);
        await queryRunner.query(`ALTER TABLE "comments" DROP CONSTRAINT "FK_93ce08bdbea73c0c7ee673ec35a"`);
        await queryRunner.query(`ALTER TABLE "subtasks" DROP CONSTRAINT "FK_eb5771e0391b13089e4ede56b30"`);
        await queryRunner.query(`ALTER TABLE "subtasks" DROP CONSTRAINT "FK_6f3a929526afab69f4bd5a05e3d"`);
        await queryRunner.query(`ALTER TABLE "attachments" ADD "uploaded_by_id" uuid`);
        await queryRunner.query(`ALTER TABLE "attachments" ADD "is_available" boolean NOT NULL DEFAULT true`);
        await queryRunner.query(`ALTER TABLE "attachments" ADD "deleted_at" TIMESTAMP WITH TIME ZONE`);
        await queryRunner.query(`ALTER TABLE "attachments" ADD "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "comments" ADD "is_available" boolean NOT NULL DEFAULT true`);
        await queryRunner.query(`ALTER TABLE "comments" ADD "deleted_at" TIMESTAMP WITH TIME ZONE`);
        await queryRunner.query(`ALTER TABLE "comments" ADD "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "subtasks" ADD "is_available" boolean NOT NULL DEFAULT true`);
        await queryRunner.query(`ALTER TABLE "subtasks" ADD "deleted_at" TIMESTAMP WITH TIME ZONE`);
        await queryRunner.query(`ALTER TABLE "subtasks" ADD "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "subtasks" ADD "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "user" ADD "isActivated" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "tasks" ADD "is_available" boolean NOT NULL DEFAULT true`);
        await queryRunner.query(`ALTER TABLE "attachments" ALTER COLUMN "subtask_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "comments" ALTER COLUMN "subtask_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "user" ALTER COLUMN "isActive" SET DEFAULT true`);
        await queryRunner.query(`ALTER TABLE "attachments" ADD CONSTRAINT "FK_8c06b12c64701f1c4f5235288b0" FOREIGN KEY ("subtask_id") REFERENCES "subtasks"("subtask_id") ON DELETE SET NULL ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "comments" ADD CONSTRAINT "FK_6e8005efa61bc3ec37a0b0cc1ae" FOREIGN KEY ("subtask_id") REFERENCES "subtasks"("subtask_id") ON DELETE SET NULL ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "comments" ADD CONSTRAINT "FK_93ce08bdbea73c0c7ee673ec35a" FOREIGN KEY ("parent_comment_id") REFERENCES "comments"("comment_id") ON DELETE SET NULL ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "subtasks" ADD CONSTRAINT "FK_eb5771e0391b13089e4ede56b30" FOREIGN KEY ("reporter_id") REFERENCES "user"("user_id") ON DELETE SET NULL ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "subtasks" ADD CONSTRAINT "FK_6f3a929526afab69f4bd5a05e3d" FOREIGN KEY ("assignee_id") REFERENCES "user"("user_id") ON DELETE SET NULL ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "subtasks" DROP CONSTRAINT "FK_6f3a929526afab69f4bd5a05e3d"`);
        await queryRunner.query(`ALTER TABLE "subtasks" DROP CONSTRAINT "FK_eb5771e0391b13089e4ede56b30"`);
        await queryRunner.query(`ALTER TABLE "comments" DROP CONSTRAINT "FK_93ce08bdbea73c0c7ee673ec35a"`);
        await queryRunner.query(`ALTER TABLE "comments" DROP CONSTRAINT "FK_6e8005efa61bc3ec37a0b0cc1ae"`);
        await queryRunner.query(`ALTER TABLE "attachments" DROP CONSTRAINT "FK_8c06b12c64701f1c4f5235288b0"`);
        await queryRunner.query(`ALTER TABLE "user" ALTER COLUMN "isActive" SET DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "comments" ALTER COLUMN "subtask_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "attachments" ALTER COLUMN "subtask_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "tasks" DROP COLUMN "is_available"`);
        await queryRunner.query(`ALTER TABLE "user" DROP COLUMN "isActivated"`);
        await queryRunner.query(`ALTER TABLE "subtasks" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "subtasks" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "subtasks" DROP COLUMN "deleted_at"`);
        await queryRunner.query(`ALTER TABLE "subtasks" DROP COLUMN "is_available"`);
        await queryRunner.query(`ALTER TABLE "comments" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "comments" DROP COLUMN "deleted_at"`);
        await queryRunner.query(`ALTER TABLE "comments" DROP COLUMN "is_available"`);
        await queryRunner.query(`ALTER TABLE "attachments" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "attachments" DROP COLUMN "deleted_at"`);
        await queryRunner.query(`ALTER TABLE "attachments" DROP COLUMN "is_available"`);
        await queryRunner.query(`ALTER TABLE "attachments" DROP COLUMN "uploaded_by_id"`);
        await queryRunner.query(`ALTER TABLE "subtasks" ADD CONSTRAINT "FK_6f3a929526afab69f4bd5a05e3d" FOREIGN KEY ("assignee_id") REFERENCES "user"("user_id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "subtasks" ADD CONSTRAINT "FK_eb5771e0391b13089e4ede56b30" FOREIGN KEY ("reporter_id") REFERENCES "user"("user_id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "comments" ADD CONSTRAINT "FK_93ce08bdbea73c0c7ee673ec35a" FOREIGN KEY ("parent_comment_id") REFERENCES "comments"("comment_id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "comments" ADD CONSTRAINT "FK_6e8005efa61bc3ec37a0b0cc1ae" FOREIGN KEY ("subtask_id") REFERENCES "subtasks"("subtask_id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "attachments" ADD CONSTRAINT "FK_8c06b12c64701f1c4f5235288b0" FOREIGN KEY ("subtask_id") REFERENCES "subtasks"("subtask_id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

}
