import { MigrationInterface, QueryRunner } from "typeorm";

export class ImageEntityAdded1758282401401 implements MigrationInterface {
    name = 'ImageEntityAdded1758282401401'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "user" ADD "profileImage" character varying NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "user" DROP COLUMN "profileImage"`);
    }

}
