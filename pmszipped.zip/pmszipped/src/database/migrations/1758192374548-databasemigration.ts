import { MigrationInterface, QueryRunner } from "typeorm";

export class Databasemigration1758192374548 implements MigrationInterface {
    name = 'Databasemigration1758192374548'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "project_members" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "project_id" uuid NOT NULL, "user_id" uuid NOT NULL, "role" character varying(30) NOT NULL, "joined_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(), "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(), "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP WITH TIME ZONE, CONSTRAINT "UQ_project_member_unique" UNIQUE ("project_id", "user_id"), CONSTRAINT "PK_0b2f46f804be4aea9234c78bcc9" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE INDEX "IDX_b5729113570c20c7e214cf3f58" ON "project_members" ("project_id") `);
        await queryRunner.query(`CREATE INDEX "IDX_e89aae80e010c2faa72e6a49ce" ON "project_members" ("user_id") `);
        await queryRunner.query(`CREATE TABLE "attachments" ("attachment_id" uuid NOT NULL DEFAULT uuid_generate_v4(), "filename" character varying(255) NOT NULL, "cloud_public_id" character varying(255) NOT NULL, "secure_url" character varying(1000) NOT NULL, "resource_type" character varying(50), "mime_type" character varying(255), "size" bigint, "is_public" boolean NOT NULL DEFAULT false, "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(), "subtask_id" uuid NOT NULL, "uploaded_by" uuid, CONSTRAINT "PK_0f0c0f540cbf0f2e9499f9a082e" PRIMARY KEY ("attachment_id"))`);
        await queryRunner.query(`CREATE TABLE "comments" ("comment_id" uuid NOT NULL DEFAULT uuid_generate_v4(), "content_html" text NOT NULL, "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(), "subtask_id" uuid NOT NULL, "author_id" uuid, "parent_comment_id" uuid, CONSTRAINT "PK_eb0d76f2ca45d66a7de04c7c72b" PRIMARY KEY ("comment_id"))`);
        await queryRunner.query(`CREATE TYPE "public"."subtasks_status_enum" AS ENUM('COMPLETED', 'ON_HOLD', 'ON_PROGRESS', 'PENDING')`);
        await queryRunner.query(`CREATE TABLE "subtasks" ("subtask_id" uuid NOT NULL DEFAULT uuid_generate_v4(), "title" character varying NOT NULL, "status" "public"."subtasks_status_enum" NOT NULL DEFAULT 'ON_PROGRESS', "description" text, "start_date" date, "end_date" date, "task_id" uuid, "reporter_id" uuid, "assignee_id" uuid, CONSTRAINT "PK_d7d334afab171bd8b56de9101d8" PRIMARY KEY ("subtask_id"))`);
        await queryRunner.query(`CREATE TABLE "notifications" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "message" character varying NOT NULL, "isRead" boolean NOT NULL DEFAULT false, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "userUserId" uuid, CONSTRAINT "PK_6a72c3c0f683f6462415e653c3a" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TYPE "public"."user_role_enum" AS ENUM('ADMIN', 'USER')`);
        await queryRunner.query(`CREATE TABLE "user" ("user_id" uuid NOT NULL DEFAULT uuid_generate_v4(), "first_name" character varying(80) NOT NULL, "last_name" character varying(80) NOT NULL, "email" character varying NOT NULL, "password" character varying(255), "phone" character varying(20) NOT NULL, "designation" character varying(120) NOT NULL, "avatar" text, "department_name" character varying(120), "user_role" "public"."user_role_enum" NOT NULL DEFAULT 'USER', "passwordResetToken" character varying(255), "passwordResetExpires" TIMESTAMP WITH TIME ZONE, "isActive" boolean NOT NULL DEFAULT false, "created_by" uuid, CONSTRAINT "UQ_e12875dfb3b1d92d7d7c5377e22" UNIQUE ("email"), CONSTRAINT "UQ_8e1f623798118e629b46a9e6299" UNIQUE ("phone"), CONSTRAINT "PK_758b8ce7c18b9d347461b30228d" PRIMARY KEY ("user_id"))`);
        await queryRunner.query(`CREATE TABLE "projects" ("project_id" uuid NOT NULL DEFAULT uuid_generate_v4(), "title" character varying(255) NOT NULL, "description" text, "start_date" date, "end_date" date, "project_roles" text array NOT NULL DEFAULT '{}', "project_status" character varying(30) NOT NULL DEFAULT 'ON_PROGRESS', "ownerUserId" uuid NOT NULL, "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(), "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP WITH TIME ZONE, CONSTRAINT "PK_b3613537a59b41f5811258edf99" PRIMARY KEY ("project_id"))`);
        await queryRunner.query(`CREATE INDEX "IDX_30f70ec4c2d480f78aa5592577" ON "projects" ("ownerUserId") `);
        await queryRunner.query(`CREATE INDEX "IDX_2117ba29bd245f2b53c42f429c" ON "projects" ("title") `);
        await queryRunner.query(`CREATE TYPE "public"."tasks_priority_enum" AS ENUM('LOW', 'MEDIUM', 'HIGH')`);
        await queryRunner.query(`CREATE TYPE "public"."tasks_status_enum" AS ENUM('COMPLETED', 'ON_HOLD', 'ON_PROGRESS', 'PENDING')`);
        await queryRunner.query(`CREATE TABLE "tasks" ("task_id" uuid NOT NULL DEFAULT uuid_generate_v4(), "title" character varying(255) NOT NULL, "description" text, "priority" "public"."tasks_priority_enum" NOT NULL DEFAULT 'MEDIUM', "status" "public"."tasks_status_enum" NOT NULL DEFAULT 'ON_PROGRESS', "start_date" TIMESTAMP WITH TIME ZONE, "due_date" TIMESTAMP WITH TIME ZONE, "estimate_minutes" integer, "order_index" integer NOT NULL DEFAULT '0', "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(), "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP WITH TIME ZONE, "project_id" uuid, "assigned_to_id" uuid, "created_by" uuid, CONSTRAINT "PK_3feca00d238e5cf50185fab8d46" PRIMARY KEY ("task_id"))`);
        await queryRunner.query(`CREATE INDEX "IDX_067be4bd67747aa64451933929" ON "tasks" ("title") `);
        await queryRunner.query(`CREATE TABLE "worklogs" ("worklog_id" uuid NOT NULL DEFAULT uuid_generate_v4(), "date" date NOT NULL, "minutes" integer NOT NULL, "note" text, "task_id" uuid, "user_id" uuid, CONSTRAINT "PK_9f3757f8255a7f8ec857347b50b" PRIMARY KEY ("worklog_id"))`);
        await queryRunner.query(`CREATE TABLE "project_targets" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "month" date NOT NULL, "target_count" integer NOT NULL, CONSTRAINT "PK_5f1dda3db400285fe60c0d0dde4" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "project_members" ADD CONSTRAINT "FK_b5729113570c20c7e214cf3f58d" FOREIGN KEY ("project_id") REFERENCES "projects"("project_id") ON DELETE RESTRICT ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "project_members" ADD CONSTRAINT "FK_e89aae80e010c2faa72e6a49ce8" FOREIGN KEY ("user_id") REFERENCES "user"("user_id") ON DELETE RESTRICT ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "attachments" ADD CONSTRAINT "FK_8c06b12c64701f1c4f5235288b0" FOREIGN KEY ("subtask_id") REFERENCES "subtasks"("subtask_id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "attachments" ADD CONSTRAINT "FK_e25812e3fd9b3f3edf11b2c5d58" FOREIGN KEY ("uploaded_by") REFERENCES "user"("user_id") ON DELETE SET NULL ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "comments" ADD CONSTRAINT "FK_6e8005efa61bc3ec37a0b0cc1ae" FOREIGN KEY ("subtask_id") REFERENCES "subtasks"("subtask_id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "comments" ADD CONSTRAINT "FK_e6d38899c31997c45d128a8973b" FOREIGN KEY ("author_id") REFERENCES "user"("user_id") ON DELETE SET NULL ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "comments" ADD CONSTRAINT "FK_93ce08bdbea73c0c7ee673ec35a" FOREIGN KEY ("parent_comment_id") REFERENCES "comments"("comment_id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "subtasks" ADD CONSTRAINT "FK_4f5962cd050efba5fcc6a5d86d6" FOREIGN KEY ("task_id") REFERENCES "tasks"("task_id") ON DELETE SET NULL ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "subtasks" ADD CONSTRAINT "FK_eb5771e0391b13089e4ede56b30" FOREIGN KEY ("reporter_id") REFERENCES "user"("user_id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "subtasks" ADD CONSTRAINT "FK_6f3a929526afab69f4bd5a05e3d" FOREIGN KEY ("assignee_id") REFERENCES "user"("user_id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "notifications" ADD CONSTRAINT "FK_c5cc52b42fde832d730c437e40f" FOREIGN KEY ("userUserId") REFERENCES "user"("user_id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "user" ADD CONSTRAINT "FK_d2f5e343630bd8b7e1e7534e82e" FOREIGN KEY ("created_by") REFERENCES "user"("user_id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "projects" ADD CONSTRAINT "FK_30f70ec4c2d480f78aa55925777" FOREIGN KEY ("ownerUserId") REFERENCES "user"("user_id") ON DELETE RESTRICT ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "tasks" ADD CONSTRAINT "FK_9eecdb5b1ed8c7c2a1b392c28d4" FOREIGN KEY ("project_id") REFERENCES "projects"("project_id") ON DELETE SET NULL ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "tasks" ADD CONSTRAINT "FK_9430f12c5a1604833f64595a57f" FOREIGN KEY ("assigned_to_id") REFERENCES "user"("user_id") ON DELETE SET NULL ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "tasks" ADD CONSTRAINT "FK_9fc727aef9e222ebd09dc8dac08" FOREIGN KEY ("created_by") REFERENCES "user"("user_id") ON DELETE SET NULL ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "worklogs" ADD CONSTRAINT "FK_9f4bdfd65c712bb44bda6f41700" FOREIGN KEY ("task_id") REFERENCES "tasks"("task_id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "worklogs" ADD CONSTRAINT "FK_3ddbc0818ceb9308c8e9d47876b" FOREIGN KEY ("user_id") REFERENCES "user"("user_id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "worklogs" DROP CONSTRAINT "FK_3ddbc0818ceb9308c8e9d47876b"`);
        await queryRunner.query(`ALTER TABLE "worklogs" DROP CONSTRAINT "FK_9f4bdfd65c712bb44bda6f41700"`);
        await queryRunner.query(`ALTER TABLE "tasks" DROP CONSTRAINT "FK_9fc727aef9e222ebd09dc8dac08"`);
        await queryRunner.query(`ALTER TABLE "tasks" DROP CONSTRAINT "FK_9430f12c5a1604833f64595a57f"`);
        await queryRunner.query(`ALTER TABLE "tasks" DROP CONSTRAINT "FK_9eecdb5b1ed8c7c2a1b392c28d4"`);
        await queryRunner.query(`ALTER TABLE "projects" DROP CONSTRAINT "FK_30f70ec4c2d480f78aa55925777"`);
        await queryRunner.query(`ALTER TABLE "user" DROP CONSTRAINT "FK_d2f5e343630bd8b7e1e7534e82e"`);
        await queryRunner.query(`ALTER TABLE "notifications" DROP CONSTRAINT "FK_c5cc52b42fde832d730c437e40f"`);
        await queryRunner.query(`ALTER TABLE "subtasks" DROP CONSTRAINT "FK_6f3a929526afab69f4bd5a05e3d"`);
        await queryRunner.query(`ALTER TABLE "subtasks" DROP CONSTRAINT "FK_eb5771e0391b13089e4ede56b30"`);
        await queryRunner.query(`ALTER TABLE "subtasks" DROP CONSTRAINT "FK_4f5962cd050efba5fcc6a5d86d6"`);
        await queryRunner.query(`ALTER TABLE "comments" DROP CONSTRAINT "FK_93ce08bdbea73c0c7ee673ec35a"`);
        await queryRunner.query(`ALTER TABLE "comments" DROP CONSTRAINT "FK_e6d38899c31997c45d128a8973b"`);
        await queryRunner.query(`ALTER TABLE "comments" DROP CONSTRAINT "FK_6e8005efa61bc3ec37a0b0cc1ae"`);
        await queryRunner.query(`ALTER TABLE "attachments" DROP CONSTRAINT "FK_e25812e3fd9b3f3edf11b2c5d58"`);
        await queryRunner.query(`ALTER TABLE "attachments" DROP CONSTRAINT "FK_8c06b12c64701f1c4f5235288b0"`);
        await queryRunner.query(`ALTER TABLE "project_members" DROP CONSTRAINT "FK_e89aae80e010c2faa72e6a49ce8"`);
        await queryRunner.query(`ALTER TABLE "project_members" DROP CONSTRAINT "FK_b5729113570c20c7e214cf3f58d"`);
        await queryRunner.query(`DROP TABLE "project_targets"`);
        await queryRunner.query(`DROP TABLE "worklogs"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_067be4bd67747aa64451933929"`);
        await queryRunner.query(`DROP TABLE "tasks"`);
        await queryRunner.query(`DROP TYPE "public"."tasks_status_enum"`);
        await queryRunner.query(`DROP TYPE "public"."tasks_priority_enum"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_2117ba29bd245f2b53c42f429c"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_30f70ec4c2d480f78aa5592577"`);
        await queryRunner.query(`DROP TABLE "projects"`);
        await queryRunner.query(`DROP TABLE "user"`);
        await queryRunner.query(`DROP TYPE "public"."user_role_enum"`);
        await queryRunner.query(`DROP TABLE "notifications"`);
        await queryRunner.query(`DROP TABLE "subtasks"`);
        await queryRunner.query(`DROP TYPE "public"."subtasks_status_enum"`);
        await queryRunner.query(`DROP TABLE "comments"`);
        await queryRunner.query(`DROP TABLE "attachments"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_e89aae80e010c2faa72e6a49ce"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_b5729113570c20c7e214cf3f58"`);
        await queryRunner.query(`DROP TABLE "project_members"`);
    }

}
