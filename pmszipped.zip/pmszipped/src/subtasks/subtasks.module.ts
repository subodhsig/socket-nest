import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from 'src/auth/auth.module';
import { CloudinaryService } from 'src/common/services/cloudinary.service';
import { Task } from 'src/tasks/entities/task.entity';
import { User } from 'src/user/entities/user.entity';
import { Comment } from '../comments/entities/comment.entity';

import { AttachmentsModule } from 'src/attachments/attachments.module';
import { Attachment } from 'src/attachments/entities/attachment.entity';
import { CommentsModule } from 'src/comments/comments.module';
import { Subtask } from './entities/subtask.entity';
import { SubtasksController } from './subtasks.controller';
import { SubtasksService } from './subtasks.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([Subtask, Attachment, Comment, User, Task]),
    AuthModule,
    AttachmentsModule,
    CommentsModule,
  ],
  providers: [SubtasksService, CloudinaryService],
  controllers: [SubtasksController],
  exports: [SubtasksService],
})
export class SubtasksModule {}
