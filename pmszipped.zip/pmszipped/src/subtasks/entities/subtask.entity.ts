import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Attachment } from '../../attachments/entities/attachment.entity';
import { Comment } from '../../comments/entities/comment.entity';
import { TaskStatus } from '../../common/enums/task.status.enum';
import { Task } from '../../tasks/entities/task.entity';
import { User } from '../../user/entities/user.entity';

@Entity({ name: 'subtasks' })
export class Subtask {
  @PrimaryGeneratedColumn('uuid')
  subtask_id: string;

  @ManyToOne(() => Task, (t) => t.subtasks, {
    nullable: true,
    onDelete: 'SET NULL',
  })
  @JoinColumn({ name: 'task_id' })
  task?: Task | null;

  @Column()
  title: string;

  @Column({ type: 'enum', enum: TaskStatus, default: TaskStatus.ON_PROGRESS })
  status: TaskStatus;

  @Column({ type: 'text', nullable: true })
  description: string | null;

  @Column({ type: 'date', nullable: true })
  start_date: Date | null;

  @Column({ type: 'date', nullable: true })
  end_date: Date | null;

  @ManyToOne(() => User, (u) => u.reported_subtasks, {
    nullable: true,
    onDelete: 'SET NULL',
  })
  @JoinColumn({ name: 'reporter_id' })
  reporter?: User | null;

  @ManyToOne(() => User, (u) => u.assigned_subtasks, {
    nullable: true,
    onDelete: 'SET NULL',
  })
  @JoinColumn({ name: 'assignee_id' })
  assignee?: User | null;

  @OneToMany(() => Attachment, (a) => a.subtask)
  attachments?: Attachment[];

  @OneToMany(() => Comment, (c) => c.subtask)
  comments?: Comment[];

  @Column({ type: 'boolean', default: true })
  is_available: boolean;

  @DeleteDateColumn({ type: 'timestamptz', nullable: true })
  deleted_at: Date | null;

  @CreateDateColumn({ type: 'timestamptz' })
  created_at: Date;

  @UpdateDateColumn({ type: 'timestamptz' })
  updated_at: Date;
}
