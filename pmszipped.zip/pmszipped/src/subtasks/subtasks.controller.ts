import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  UploadedFiles,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { FilesInterceptor } from '@nestjs/platform-express';
import {
  ApiBearerAuth,
  ApiBody,
  ApiConsumes,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';

import { GetUser } from 'src/auth/decorators/getuser.decorator';
import { Roles } from 'src/auth/decorators/roles.decorators';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { RolesGuard } from 'src/auth/guards/roles.guard';
import { TaskStatus } from 'src/common/enums/task.status.enum';
import { Role } from 'src/common/enums/user.role.enum';
import { CreateSubtaskDto } from './dto/create-subtask.dto';
import { UpdateSubtaskDto } from './dto/update-subtask.dto';
import { SubtasksService } from './subtasks.service';

type JwtUser = { user_id: string; email: string; role: Role };

@ApiTags('Subtasks')
@ApiBearerAuth()
@Controller('subtasks')
@UseGuards(JwtAuthGuard, RolesGuard)
export class SubtasksController {
  constructor(private readonly service: SubtasksService) {}

  /** Create a new subtask (Admin only, with optional attachments) */
  @Post()
  @Roles(Role.ADMIN)
  @UseInterceptors(FilesInterceptor('files'))
  @ApiOperation({ summary: 'Create subtask (Admin only)' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    description: 'Create subtask with optional file attachments',
    schema: {
      type: 'object',
      properties: {
        title: { type: 'string' },
        description: { type: 'string' },
        task_id: { type: 'string', format: 'uuid' },
        assignee_id: { type: 'string', format: 'uuid' },
        reporter_id: { type: 'string', format: 'uuid' },
        start_date: { type: 'string', format: 'date-time' },
        end_date: { type: 'string', format: 'date-time' },
        status: { type: 'string', enum: Object.values(TaskStatus) },
        files: {
          type: 'array',
          items: { type: 'string', format: 'binary' },
          nullable: true,
        },
      },
      required: ['title', 'task_id'],
    },
  })
  create(
    @Body() dto: CreateSubtaskDto,
    @GetUser() actor: JwtUser,
    @UploadedFiles() files: Express.Multer.File[],
  ) {
    return this.service.create(dto, actor, files);
  }

  /** Update an existing subtask (Admin only) */
  // @Patch(':subtask_id')
  // @Roles(Role.ADMIN)
  // @ApiOperation({ summary: 'Update subtask (Admin only)' })
  // update(
  //   @Param('subtask_id') subtask_id: string,
  //   @Body() dto: UpdateSubtaskDto,
  //   @GetUser() actor: JwtUser,
  // ) {
  //   return this.service.update(subtask_id, dto, actor);
  // }

  @Patch(':subtask_id')
  @Roles(Role.ADMIN)
  @UseInterceptors(FilesInterceptor('files'))
  @ApiOperation({ summary: 'Update subtask (Admin only)' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    description: 'Update subtask with optional file attachments',
    schema: {
      type: 'object',
      properties: {
        title: { type: 'string' },
        description: { type: 'string' },
        assignee_id: { type: 'string', format: 'uuid' },
        reporter_id: { type: 'string', format: 'uuid' },
        start_date: { type: 'string', format: 'date-time' },
        end_date: { type: 'string', format: 'date-time' },
        status: { type: 'string', enum: Object.values(TaskStatus) },
        files: {
          type: 'array',
          items: { type: 'string', format: 'binary' },
          nullable: true,
        },
      },
      required: [],
    },
  })
  update(
    @Param('subtask_id') subtask_id: string,
    @Body() dto: UpdateSubtaskDto,
    @GetUser() actor: JwtUser,
    @UploadedFiles() files: Express.Multer.File[],
  ) {
    return this.service.update(subtask_id, dto, actor, files);
  }

  /** Delete a subtask (Admin only) */
  @Delete(':subtask_id')
  @Roles(Role.ADMIN)
  @ApiOperation({ summary: 'Delete subtask (Admin only)' })
  remove(@Param('subtask_id') subtask_id: string, @GetUser() actor: JwtUser) {
    return this.service.remove(subtask_id, actor);
  }

  /** Get all subtasks for a given task (Members/Assignees allowed) */
  @ApiOperation({ summary: 'Get all subtasks for a task' })
  @Get('task/:task_id')
  findByTask(@Param('task_id') task_id: string, @GetUser() actor: JwtUser) {
    return this.service.findByTask(task_id, actor);
  }

  /** Get a single subtask by ID (Members/Assignees allowed) */
  @Get(':subtask_id')
  @ApiOperation({ summary: 'Get a single subtask by ID' })
  findOne(@Param('subtask_id') subtask_id: string, @GetUser() actor: JwtUser) {
    return this.service.findOne(subtask_id, actor);
  }
}
