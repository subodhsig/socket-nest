import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsDateString,
  IsEnum,
  IsOptional,
  IsString,
  IsUUID,
  Length,
} from 'class-validator';
import { TaskStatus } from 'src/common/enums/task.status.enum';

export class CreateSubtaskDto {
  @ApiProperty({
    description: 'Title of the subtask',
    example: 'Design Homepage',
  })
  @Length(3, 160)
  @IsString()
  title: string;

  @ApiPropertyOptional({ description: 'Description of the subtask' })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({
    description: 'Subtask start date',
    type: String,
    format: 'date-time',
  })
  @IsOptional()
  @IsDateString()
  start_date?: string;

  @ApiPropertyOptional({
    description: 'Subtask end date',
    type: String,
    format: 'date-time',
  })
  @IsOptional()
  @IsDateString()
  end_date?: string;

  @ApiPropertyOptional({ description: 'Reporter user ID (optional)' })
  @IsOptional()
  @IsUUID()
  reporter_id?: string;

  @ApiPropertyOptional({ description: 'Assignee user ID (optional)' })
  @IsOptional()
  @IsUUID()
  assignee_id?: string;

  @ApiProperty({ description: 'Parent task ID' })
  @IsUUID()
  task_id: string;

  @ApiPropertyOptional({
    description: 'Status of the subtask',
    enum: TaskStatus,
  })
  @IsOptional()
  @IsEnum(TaskStatus)
  status?: TaskStatus;

  @ApiPropertyOptional({ type: 'string', format: 'binary', isArray: true })
  @IsOptional()
  files?: any;
}
