import {
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { IsNull, Repository } from 'typeorm';

import { Role } from 'src/common/enums/user.role.enum';
import { AttachmentsService } from '../attachments/attachments.service';
import { Task } from '../tasks/entities/task.entity';
import { User } from '../user/entities/user.entity';
import { CreateSubtaskDto } from './dto/create-subtask.dto';
import { UpdateSubtaskDto } from './dto/update-subtask.dto';
import { Subtask } from './entities/subtask.entity';

type JwtUser = { user_id: string; email: string; role: Role };

@Injectable()
export class SubtasksService {
  constructor(
    @InjectRepository(Subtask)
    private readonly repo: Repository<Subtask>,
    @InjectRepository(Task)
    private readonly tasks: Repository<Task>,
    @InjectRepository(User)
    private readonly users: Repository<User>,
    private readonly attachmentsService: AttachmentsService,
  ) {}

  /**
   * Helper: check if actor can access task/subtask
   */
  private async ensureCanAccessTask(task_id: string, actor: JwtUser) {
    if (actor.role === Role.ADMIN) return;

    const task = await this.tasks.findOne({
      where: { task_id },
      relations: [
        'project',
        'project.members',
        'project.members.user',
        'assignee',
        'subtasks',
        'subtasks.assignee',
      ],
    });

    if (!task) throw new NotFoundException('Task not found');

    const isProjectMember = task.project?.members?.some(
      (m) => m.user?.user_id === actor.user_id,
    );
    const isAssigned =
      task.assignee?.user_id === actor.user_id ||
      task.subtasks?.some((s) => s.assignee?.user_id === actor.user_id);

    if (!isProjectMember && !isAssigned) {
      throw new ForbiddenException(
        'You are not allowed to access this task or its subtasks',
      );
    }
  }

  /**
   * Admin creates a subtask.
   * Attachments optional (uploaded at creation time).
   */
  async create(
    dto: CreateSubtaskDto,
    actor: JwtUser,
    files?: Express.Multer.File[],
  ) {
    if (actor.role !== Role.ADMIN) {
      throw new ForbiddenException('Only admins can create subtasks');
    }

    const task = await this.tasks.findOne({
      where: { task_id: dto.task_id },
    });
    if (!task) throw new NotFoundException('Task not found');

    const subtask = this.repo.create({
      title: dto.title,
      description: dto.description ?? null,
      status: dto.status ?? undefined,
      start_date: dto.start_date ? new Date(dto.start_date) : null,
      end_date: dto.end_date ? new Date(dto.end_date) : null,
      task,
    });

    const reporter = await this.users.findOne({
      where: { user_id: actor.user_id },
    });
    subtask.reporter = reporter ?? null;

    if (dto.assignee_id) {
      const assignee = await this.users.findOne({
        where: { user_id: dto.assignee_id },
      });
      if (!assignee) throw new NotFoundException('Assignee not found');
      subtask.assignee = assignee;
    }

    const saved = await this.repo.save(subtask);

    if (files?.length && reporter) {
      for (const file of files) {
        await this.attachmentsService.uploadToSubtask(
          saved.subtask_id,
          file,
          actor,
        );
      }
    }

    return this.findOne(saved.subtask_id, actor);
  }

  /**
   * Admin updates subtask
   */
  // async update(subtask_id: string, dto: UpdateSubtaskDto, actor: JwtUser) {
  //   if (actor.role !== Role.ADMIN) {
  //     throw new ForbiddenException('Only admins can update subtasks');
  //   }

  //   const subtask = await this.repo.findOne({ where: { subtask_id } });
  //   if (!subtask) throw new NotFoundException('Subtask not found');

  //   Object.assign(subtask, {
  //     ...dto,
  //     start_date: dto.start_date
  //       ? new Date(dto.start_date)
  //       : subtask.start_date,
  //     end_date: dto.end_date ? new Date(dto.end_date) : subtask.end_date,
  //   });

  //   return this.repo.save(subtask);
  // }

  async update(
    subtask_id: string,
    dto: UpdateSubtaskDto,
    actor: JwtUser,
    files?: Express.Multer.File[],
  ) {
    if (actor.role !== Role.ADMIN) {
      throw new ForbiddenException('Only admins can update subtasks');
    }

    const subtask = await this.repo.findOne({ where: { subtask_id } });
    if (!subtask) throw new NotFoundException('Subtask not found');

    Object.assign(subtask, {
      ...dto,
      start_date: dto.start_date
        ? new Date(dto.start_date)
        : subtask.start_date,
      end_date: dto.end_date ? new Date(dto.end_date) : subtask.end_date,
    });

    const saved = await this.repo.save(subtask);

    // 🔹 handle file uploads (optional)
    if (files?.length) {
      for (const file of files) {
        await this.attachmentsService.uploadToSubtask(
          saved.subtask_id,
          file,
          actor,
        );
      }
    }

    return this.findOne(saved.subtask_id, actor);
  }

  /**
   * Admin deletes a subtask
   */
  async remove(subtask_id: string, actor: JwtUser) {
    if (actor.role !== Role.ADMIN) {
      throw new ForbiddenException('Only admins can delete subtasks');
    }

    const subtask = await this.repo.findOne({ where: { subtask_id } });
    if (!subtask) throw new NotFoundException('Subtask not found');

    subtask.is_available = false;
    subtask.deleted_at = new Date();
    await this.repo.save(subtask);

    return { success: true };
  }

  /**
   * Admin + Users can view one subtask
   */
  async findOne(subtask_id: string, actor: JwtUser) {
    if (!actor) {
      throw new NotFoundException('User not found');
    }
    const subtask = await this.repo.findOne({
      where: { subtask_id, deleted_at: IsNull(), is_available: true },
      relations: [
        'assignee',
        'reporter',
        'attachments',
        'attachments.uploaded_by',
        'comments',
        'comments.author',
      ],
    });

    if (!subtask) throw new NotFoundException('Subtask not found');

    return subtask;
  }

  /**
   * Admin + Users can list subtasks of a task
   */
  async findByTask(task_id: string, actor: JwtUser) {
    await this.ensureCanAccessTask(task_id, actor);

    return this.repo.find({
      where: {
        task: { task_id },
        deleted_at: IsNull(),
        is_available: true,
      },
      relations: [
        'assignee',
        'reporter',
        'attachments',
        'attachments.uploaded_by',
        'comments',
        'comments.author',
      ],
      order: { title: 'ASC' },
    });
  }
}
