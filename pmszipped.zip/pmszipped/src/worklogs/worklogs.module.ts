import { Module } from '@nestjs/common';
import { WorkLogController } from './worklogs.controller';
import { WorkLogService } from './worklogs.service';
import { Project } from 'src/projects/entities/project.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Worklog } from './entities/worklog.entity';
import { ProjectTarget } from 'src/projects/entities/project-target.entity';
import { Task } from 'src/tasks/entities/task.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Worklog, Project, ProjectTarget, Task])],
  controllers: [WorkLogController],
  providers: [WorkLogService],
})
export class WorklogsModule {}
