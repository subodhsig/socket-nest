import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Between, Repository } from 'typeorm';
import { calculateWorkingDays } from './utils/date.utils';
import { Project } from 'src/projects/entities/project.entity';
import { ProjectTarget } from 'src/projects/entities/project-target.entity';
import { ProjectStatus } from 'src/common/enums/project.status.enum';
import { Worklog } from './entities/worklog.entity';
import { CreateWorklogDto } from './dto/create-worklog.dto';
import { Task } from 'src/tasks/entities/task.entity';
import { TaskStatus } from 'src/common/enums/task.status.enum';

@Injectable()
export class WorkLogService {
  constructor(
    @InjectRepository(Project)
    private projectRepository: Repository<Project>,
    @InjectRepository(ProjectTarget)
    private readonly targetRepo: Repository<ProjectTarget>,
    @InjectRepository(Worklog)
    private readonly worklogRepo: Repository<Worklog>,
    @InjectRepository(Task)
    private readonly taskRepo: Repository<Task>,
  ) {}

  async getProjectWorkingDays(projectId: string) {
    const project = await this.projectRepository.findOne({
      where: { project_id: projectId },
    });
    if (!project) throw new NotFoundException('Project not found');

    const today = new Date();
    const workingDays = calculateWorkingDays(project.created_at, today);

    return {
      projectId: project.project_id,
      projectName: project.title,
      createdAt: project.created_at,
      workingDays,
    };
  }
  async getAllProjectsWorkingDays() {
    const projects = await this.projectRepository.find();
    const today = new Date();

    return projects.map((project) => {
      const createdAt = new Date(project.created_at);
      const endDate = project.end_date ? new Date(project.end_date) : today; // use real end date if available

      const totalDays = calculateWorkingDays(createdAt, endDate);
      const workingDays = calculateWorkingDays(createdAt, today);

      // Prevent divide-by-zero
      const progressPercentage =
        totalDays > 0 ? Math.min((workingDays / totalDays) * 100, 100) : 0;

      return {
        projectId: project.project_id,
        projectName: project.title,
        createdAt: project.created_at,
        endDate: project.end_date ?? null,
        workingDays,
        totalDays,
        progressPercentage: Number(progressPercentage.toFixed(2)), // round to 2 decimals
      };
    });
  }

  async getPerformance(startDate: string, endDate: string) {
    // 1. Fetch achieved projects grouped by month
    const achieved = await this.projectRepository
      .createQueryBuilder('project')
      .select("DATE_TRUNC('month', project.end_date)", 'month')
      .addSelect('COUNT(*)', 'count')
      .where('project.project_status = :status', {
        status: ProjectStatus.COMPLETED,
      })
      .andWhere('project.end_date BETWEEN :start AND :end', {
        start: startDate,
        end: endDate,
      })
      .groupBy('month')
      .orderBy('month', 'ASC')
      .getRawMany();

    // 2. Fetch targets
    const targets = await this.targetRepo.find({
      where: { month: Between(new Date(startDate), new Date(endDate)) },
      order: { month: 'ASC' },
    });

    // 3. Merge into a single dataset
    return targets.map((t) => ({
      month: t.month.toISOString().substring(0, 7), // e.g. "2022-01"
      target: t.target_count,
      achieved:
        achieved.find(
          (a) =>
            a.month.substring(0, 7) === t.month.toISOString().substring(0, 7),
        )?.count || 0,
    }));
  }

  async createWorklogNote(createWorklogDto: CreateWorklogDto) {
    const notes = await this.worklogRepo.save(createWorklogDto);
    return notes;
  }

  async getWorklogNotesByProject() {
    const notes = await this.worklogRepo.find();
    return notes;
  }
  async CompletedTimeOfTaskAndEstimateTotalTimeByUser(userId: string) {
    const [completedRaw, allRaw] = await Promise.all([
      this.taskRepo
        .createQueryBuilder('t')
        .select('SUM(t.estimate_minutes)', 'totalEstimate')
        .where('t.status = :status', { status: TaskStatus.COMPLETED })
        .andWhere('t.deleted_at IS NULL')
        .andWhere('t.assignee.user_id = :userId', { userId })
        .getRawOne(),

      this.taskRepo
        .createQueryBuilder('t')
        .select('SUM(t.estimate_minutes)', 'totalEstimate')
        .where('t.deleted_at IS NULL')
        .andWhere('t.assignee.user_id = :userId', { userId })
        .getRawOne(),
    ]);

    const completedTasksTime = Number(
      (completedRaw as { totalEstimate?: string })?.totalEstimate ?? 0,
    );
    const allTasksEstimate = Number(
      (allRaw as { totalEstimate?: string })?.totalEstimate ?? 0,
    );

    const completedPercentage =
      allTasksEstimate > 0 ? (completedTasksTime / allTasksEstimate) * 100 : 0;

    return {
      userId,
      completedTasksTime,
      allTasksEstimate,
      completedPercentage: Number(completedPercentage.toFixed(2)),
    };
  }
}
