import { ApiProperty } from '@nestjs/swagger';
import { IsString } from 'class-validator';

export class CreateWorklogDto {
  @ApiProperty({ example: 'Worked on project documentation' })
  @IsString()
  note: string;

  @ApiProperty({ example: '2023-10-10' })
  @IsString()
  date: Date;

  @ApiProperty({ example: 5 })
  @IsString()
  minutes: number; // in hours
}
