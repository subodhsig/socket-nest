// worklog/worklog.controller.ts
import { Controller, Get, Param } from '@nestjs/common';
import { WorkLogService } from './worklogs.service';
import { ApiOperation } from '@nestjs/swagger';

@Controller('worklogs')
export class WorkLogController {
  constructor(private readonly workLogService: WorkLogService) {}
  //route to get working days for a specific project by its ID
  @Get('project/:id/working-days')
  @ApiOperation({ summary: 'Get working days for a specific project by ID' })
  async getProjectWorkingDays(@Param('id') id: string) {
    return this.workLogService.getProjectWorkingDays(id);
  }

  @Get('projects/working-days')
  @ApiOperation({ summary: 'Get working days for all projects' })
  async getAllProjectsWorkingDays() {
    return this.workLogService.getAllProjectsWorkingDays();
  }

  @Get('performance/:startDate/:endDate')
  @ApiOperation({ summary: 'Get performance between two dates' })
  async getPerformance(
    @Param('startDate') startDate: string,
    @Param('endDate') endDate: string,
  ) {
    return this.workLogService.getPerformance(startDate, endDate);
  }

  @Get('/user/performance/:userId')
  @ApiOperation({ summary: 'Get user performance by user ID' })
  async getUserPerformance(@Param('userId') userId: string) {
    return this.workLogService.CompletedTimeOfTaskAndEstimateTotalTimeByUser(
      userId,
    );
  }
}
