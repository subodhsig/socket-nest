// utils/date.utils.ts
export function calculateWorkingDays(startDate: Date, endDate: Date): number {
  let count = 0;
  const current = new Date(startDate);

  while (current <= endDate) {
    // getDay(): 0=Sunday, 6=Saturday
    if (current.getDay() !== 6) {
      // skip Saturday only
      count++;
    }
    current.setDate(current.getDate() + 1);
  }

  return count;
}
