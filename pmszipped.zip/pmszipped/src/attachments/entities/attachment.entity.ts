import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Subtask } from '../../subtasks/entities/subtask.entity';
import { User } from '../../user/entities/user.entity';

@Entity({ name: 'attachments' })
export class Attachment {
  @PrimaryGeneratedColumn('uuid')
  attachment_id: string;

  @Column({ type: 'uuid', nullable: true })
  subtask_id: string | null;

  @ManyToOne(() => Subtask, (s) => s.attachments, {
    nullable: true,
    onDelete: 'SET NULL',
  })
  @JoinColumn({ name: 'subtask_id' })
  subtask: Subtask | null;

  @Column({ type: 'uuid', nullable: true })
  uploaded_by_id: string | null;

  @ManyToOne(() => User, (u) => u.attachments, {
    nullable: true,
    onDelete: 'SET NULL',
  })
  @JoinColumn({ name: 'uploaded_by' })
  uploaded_by: User | null;

  @Column({ length: 255 })
  filename: string;

  @Column({ length: 255 })
  cloud_public_id: string;

  @Column({ type: 'varchar', length: 1000 })
  secure_url: string;

  @Column({ type: 'varchar', length: 50, nullable: true })
  resource_type: string | null;

  @Column({ type: 'varchar', length: 255, nullable: true })
  mime_type: string | null;

  @Column({ type: 'bigint', nullable: true })
  size: number | null;

  @Column({ type: 'boolean', default: false })
  is_public: boolean;

  @Column({ type: 'boolean', default: true })
  is_available: boolean;

  @DeleteDateColumn({ type: 'timestamptz', nullable: true })
  deleted_at: Date | null;

  @CreateDateColumn({ type: 'timestamptz' })
  created_at: Date;

  @UpdateDateColumn({ type: 'timestamptz' })
  updated_at: Date;
}
