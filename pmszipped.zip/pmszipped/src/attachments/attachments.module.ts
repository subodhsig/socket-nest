import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from 'src/auth/auth.module';
import { Subtask } from 'src/subtasks/entities/subtask.entity';
import { Task } from 'src/tasks/entities/task.entity';
import { User } from 'src/user/entities/user.entity';
import { AttachmentsController } from './attachments.controller';

import { Comment } from 'src/comments/entities/comment.entity';
import { CloudinaryService } from 'src/common/services/cloudinary.service';
import { AttachmentsService } from './attachments.service';
import { Attachment } from './entities/attachment.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Subtask, Attachment, Comment, User, Task]),
    AuthModule,
  ],
  controllers: [AttachmentsController],
  providers: [AttachmentsService, CloudinaryService],
  exports: [AttachmentsService],
})
export class AttachmentsModule {}
