import {
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Role } from 'src/common/enums/user.role.enum';
import { CloudinaryService } from 'src/common/services/cloudinary.service';
import { IsNull, Repository } from 'typeorm';
import { Subtask } from '../subtasks/entities/subtask.entity';
import { User } from '../user/entities/user.entity';
import { Attachment } from './entities/attachment.entity';

type JwtUser = { user_id: string; email: string; role: Role };

@Injectable()
export class AttachmentsService {
  constructor(
    @InjectRepository(Attachment)
    private readonly repo: Repository<Attachment>,
    @InjectRepository(Subtask)
    private readonly subtasks: Repository<Subtask>,
    @InjectRepository(User)
    private readonly users: Repository<User>,
    private readonly cloudinary: CloudinaryService,
  ) {}

  /**
   * Upload and attach a file to a subtask.
   */
  async uploadToSubtask(
    subtask_id: string,
    file: Express.Multer.File,
    actor: JwtUser,
  ) {
    const subtask = await this.subtasks.findOne({
      where: { subtask_id },
      relations: ['task', 'task.project', 'task.project.members', 'assignee'],
    });
    if (!subtask) throw new NotFoundException('Subtask not found');

    // Only admins, assignees, or project members can attach
    const isProjectMember =
      subtask.task?.project?.members?.some(
        (m) => m.user?.user_id === actor.user_id,
      ) ?? false;

    const isAssignee = subtask.assignee?.user_id === actor.user_id;
    const isReporter = subtask.reporter?.user_id === actor.user_id;
    if (
      !(
        actor.role === Role.ADMIN ||
        isProjectMember ||
        isAssignee ||
        isReporter
      )
    ) {
      throw new ForbiddenException('Not allowed to attach files here');
    }
    const uploader = await this.users.findOne({
      where: { user_id: actor.user_id },
    });
    if (!uploader) throw new NotFoundException('Uploader not found');

    // Upload file to Cloudinary
    const uploadResult = await this.cloudinary.uploadFile(file);

    const attachment = this.repo.create({
      subtask,
      uploaded_by: uploader,
      filename: file.originalname,
      cloud_public_id: uploadResult.public_id,
      secure_url: uploadResult.secure_url,
      resource_type: uploadResult.resource_type,
      mime_type: file.mimetype,
      size: file.size,
      is_public: false,
    });

    return this.repo.save(attachment);
  }

  /**
   * Get all attachments for a subtask.
   */
  async findBySubtask(subtask_id: string) {
    return this.repo.find({
      where: {
        subtask_id,
        deleted_at: IsNull(),
        is_available: true,
      },
      relations: ['uploaded_by'],
      order: { created_at: 'DESC' },
    });
  }

  /**
   * Delete an attachment (uploader or admin only).
   */
  async remove(attachment_id: string, actor: JwtUser) {
    const attachment = await this.repo.findOne({
      where: { attachment_id },
      relations: ['uploaded_by'],
    });
    if (!attachment) throw new NotFoundException('Attachment not found');

    if (
      actor.role !== Role.ADMIN &&
      attachment.uploaded_by?.user_id !== actor.user_id
    ) {
      throw new ForbiddenException('Not allowed to delete this attachment');
    }

    await this.cloudinary.deleteFile(attachment.cloud_public_id);
    attachment.is_available = false;
    attachment.deleted_at = new Date();
    await this.repo.save(attachment);

    return { success: true };
  }
}
