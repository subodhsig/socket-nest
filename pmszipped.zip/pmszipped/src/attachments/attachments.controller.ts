import {
  Controller,
  Delete,
  ForbiddenException,
  Get,
  Param,
  Post,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import {
  ApiBearerAuth,
  ApiBody,
  ApiConsumes,
  ApiOperation,
  ApiParam,
  ApiTags,
} from '@nestjs/swagger';
import { GetUser } from 'src/auth/decorators/getuser.decorator';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { RolesGuard } from 'src/auth/guards/roles.guard';
import { Role } from 'src/common/enums/user.role.enum';
import { AttachmentsService } from './attachments.service';

// 👇 same shape as in service
type JwtUser = { user_id: string; email: string; role: Role };

@ApiTags('Attachments')
@ApiBearerAuth()
@Controller('attachments')
@UseGuards(JwtAuthGuard, RolesGuard)
export class AttachmentsController {
  constructor(private readonly service: AttachmentsService) {}

  /**
   * Upload a file and attach it to a subtask
   * POST /attachments/subtask/:subtask_id
   */
  @Post('subtask/:subtask_id')
  @UseInterceptors(FileInterceptor('file'))
  @ApiOperation({ summary: 'Upload file to a subtask' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  @ApiParam({ name: 'subtask_id', description: 'UUID of the subtask' })
  async upload(
    @Param('subtask_id') subtask_id: string,
    @UploadedFile() file: Express.Multer.File,
    @GetUser() actor: JwtUser, // fixed
  ) {
    if (!file) throw new ForbiddenException('File is required');
    return this.service.uploadToSubtask(subtask_id, file, actor);
  }

  /**
   * List all attachments of a subtask
   * GET /attachments/subtask/:subtask_id
   */
  @Get('subtask/:subtask_id')
  @ApiOperation({ summary: 'List all attachments for a subtask' })
  @ApiParam({ name: 'subtask_id', description: 'UUID of the subtask' })
  async listBySubtask(@Param('subtask_id') subtask_id: string) {
    return this.service.findBySubtask(subtask_id);
  }

  /**
   * Delete an attachment
   * DELETE /attachments/:attachment_id
   */
  @Delete(':attachment_id')
  @ApiOperation({ summary: 'Delete an attachment' })
  @ApiParam({ name: 'attachment_id', description: 'UUID of the attachment' })
  async remove(
    @Param('attachment_id') attachment_id: string,
    @GetUser() actor: JwtUser,
  ) {
    return this.service.remove(attachment_id, actor);
  }
}
