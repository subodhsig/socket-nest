import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsString, MinLength } from 'class-validator';

export class SearchQueryDto {
  @ApiPropertyOptional({ description: 'Search term', example: 'project x' })
  @IsOptional()
  @IsString()
  @MinLength(2)
  q?: string;

  @ApiPropertyOptional({ description: 'Max results', example: 10 })
  @IsOptional()
  limit?: number = 10;
}
