import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Project } from 'src/projects/entities/project.entity';
import { User } from 'src/user/entities/user.entity';
import { ILike, Repository } from 'typeorm';
import { SearchQueryDto } from './dto/search-query.dto';
import { SearchResult } from './interface/search-result.interface';

@Injectable()
export class SearchService {
  constructor(
    @InjectRepository(Project)
    private readonly projects: Repository<Project>,
    @InjectRepository(User)
    private readonly users: Repository<User>,
  ) {}

  async searchProjects(dto: SearchQueryDto): Promise<SearchResult<Project>> {
    const term = dto.q?.trim();

    let results: Project[];
    if (term) {
      // Search by title
      results = await this.projects.find({
        where: { title: ILike(`%${term}%`) },
        take: dto.limit,
        relations: ['owner', 'members', 'members.user'],
        order: { created_at: 'DESC' },
      });
    } else {
      // Default results when no search term
      results = await this.projects.find({
        take: dto.limit,
        relations: ['owner', 'members', 'members.user'],
        order: { created_at: 'DESC' }, // show recent projects
      });
    }

    return {
      entity: 'project',
      results,
      total: results.length,
    };
  }

  async searchUsers(dto: SearchQueryDto): Promise<SearchResult<User>> {
    const term = dto.q?.trim();

    let results: User[];
    if (term) {
      results = await this.users.find({
        where: [
          { first_name: ILike(`%${term}%`) },
          { last_name: ILike(`%${term}%`) },
          { email: ILike(`%${term}%`) },
          { phone: ILike(`%${term}%`) },
        ],
        take: dto.limit,
      });
    } else {
      results = await this.users.find({
        take: dto.limit,
      });
    }

    return {
      entity: 'user',
      results,
      total: results.length,
    };
  }
}
