import { Controller, Get, Query } from '@nestjs/common';
import { ApiOperation } from '@nestjs/swagger';
import { SearchQueryDto } from './dto/search-query.dto';
import { SearchService } from './search.service';

@Controller('search')
export class SearchController {
  constructor(private readonly searchService: SearchService) {}

  @Get('projects')
  @ApiOperation({ summary: 'Search projects' })
  searchProjects(@Query() dto: SearchQueryDto) {
    return this.searchService.searchProjects(dto);
  }

  @Get('users')
  @ApiOperation({ summary: 'Search users' })
  searchUsers(@Query() dto: SearchQueryDto) {
    return this.searchService.searchUsers(dto);
  }
}
