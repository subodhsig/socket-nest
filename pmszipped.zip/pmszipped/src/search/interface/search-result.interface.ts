export interface SearchResult<T> {
  entity: string;
  results: T[];
  total: number;
}
