export enum TaskStatus {
  COMPLETED = 'COMPLETED',
  ON_HOLD = 'ON_HOLD',
  ON_PROGRESS = 'ON_PROGRESS',
  PENDING = 'PENDING',
}
