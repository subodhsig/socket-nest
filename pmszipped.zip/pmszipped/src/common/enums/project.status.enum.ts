export enum ProjectStatus {
  COMPLETED = 'COMPLETED',
  ON_HOLD = 'ON_HOLD',
  ON_PROGRESS = 'ON_PROGRESS',
  PENDING = 'PENDING',
  OFF_TRACK = 'OFF_TRACK',
}
