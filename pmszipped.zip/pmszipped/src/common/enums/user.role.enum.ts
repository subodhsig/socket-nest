export enum Role {
  ADMIN = 'ADMIN',
  USER = 'USER',
}
