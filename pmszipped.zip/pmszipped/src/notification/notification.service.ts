import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Notification } from './entities/notification.entity';

import { NotificationGateway } from './notification.gateway';
import { User } from 'src/user/entities/user.entity';

@Injectable()
export class NotificationService {
  constructor(
    @InjectRepository(Notification)
    private notificationRepo: Repository<Notification>,
    private notificationGateway: NotificationGateway,
  ) {}

  async notifyUser(user: User, message: string) {
    const notification = this.notificationRepo.create({ user, message });
    await this.notificationRepo.save(notification);

    this.notificationGateway.sendNotification(user.user_id, message);
    return notification;
  }
  //todo: mark as read all

  async markAsRead(notificationId: string) {
    await this.notificationRepo.update(notificationId, { isRead: true });
    return { success: true };
  }

  async getUserNotifications(userId: string) {
    // Fetch notifications first
    const notifications = await this.notificationRepo.find({
      where: { user: { user_id: userId } },
      order: { createdAt: 'DESC' },
      relations: ['user'],
    });

    await this.notificationRepo.update(
      { user: { user_id: userId }, isRead: false },
      { isRead: true },
    );

    return notifications;
  }
}
